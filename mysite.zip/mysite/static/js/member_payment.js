function parse_template_to_json(template_content) {
    template_content = template_content.replace(/None/g, "\'None\'");
    template_content = template_content.replace(/'/g, "\"");
    return JSON.parse(template_content);
}

function inWords(amount) {
    var words = new Array();
    words[0] = '';
    words[1] = 'One';
    words[2] = 'Two';
    words[3] = 'Three';
    words[4] = 'Four';
    words[5] = 'Five';
    words[6] = 'Six';
    words[7] = 'Seven';
    words[8] = 'Eight';
    words[9] = 'Nine';
    words[10] = 'Ten';
    words[11] = 'Eleven';
    words[12] = 'Twelve';
    words[13] = 'Thirteen';
    words[14] = 'Fourteen';
    words[15] = 'Fifteen';
    words[16] = 'Sixteen';
    words[17] = 'Seventeen';
    words[18] = 'Eighteen';
    words[19] = 'Nineteen';
    words[20] = 'Twenty';
    words[30] = 'Thirty';
    words[40] = 'Forty';
    words[50] = 'Fifty';
    words[60] = 'Sixty';
    words[70] = 'Seventy';
    words[80] = 'Eighty';
    words[90] = 'Ninety';
    amount = amount.toString();
    var atemp = amount.split(".");
    var number = atemp[0].split(",").join("");
    var n_length = number.length;
    var words_string = "";
    if (n_length <= 9) {
        var n_array = new Array(0, 0, 0, 0, 0, 0, 0, 0, 0);
        var received_n_array = new Array();
        for (var i = 0; i < n_length; i++) {
            received_n_array[i] = number.substr(i, 1);
        }
        for (var i = 9 - n_length, j = 0; i < 9; i++, j++) {
            n_array[i] = received_n_array[j];
        }
        for (var i = 0, j = 1; i < 9; i++, j++) {
            if (i == 0 || i == 2 || i == 4 || i == 7) {
                if (n_array[i] == 1) {
                    n_array[j] = 10 + parseInt(n_array[j]);
                    n_array[i] = 0;
                }
            }
        }
        let value = "";
        for (var i = 0; i < 9; i++) {
            if (i == 0 || i == 2 || i == 4 || i == 7) {
                value = n_array[i] * 10;
            } else {
                value = n_array[i];
            }
            if (value != 0) {
                words_string += words[value] + " ";
            }
            if ((i == 1 && value != 0) || (i == 0 && value != 0 && n_array[i + 1] == 0)) {
                words_string += "Crores ";
            }
            if ((i == 3 && value != 0) || (i == 2 && value != 0 && n_array[i + 1] == 0)) {
                words_string += "Lakhs ";
            }
            if ((i == 5 && value != 0) || (i == 4 && value != 0 && n_array[i + 1] == 0)) {
                words_string += "Thousand ";
            }
            if (i == 6 && value != 0 && (n_array[i + 1] != 0 && n_array[i + 2] != 0)) {
                words_string += "Hundred and ";
            } else if (i == 6 && value != 0) {
                words_string += "Hundred ";
            }
        }
        words_string = words_string.split("  ").join(" ") + 'only';
    }
    return words_string;
}

function get_current_day() {
    // Current Date
    var today = new Date();
    var dd = today.getDate();
    var mm = today.getMonth() + 1; //January is 0!

    var yyyy = today.getFullYear();
    if (dd < 10) {
        dd = '0' + dd;
    }
    if (mm < 10) {
        mm = '0' + mm;
    }
    return (dd + '-' + mm + '-' + yyyy);
}

function convert_number_to_word(number_to_string) {
    if (parseInt(number_to_string) == 1)
        return 'First'
    if (parseInt(number_to_string) == 2)
        return 'Second'
    if (parseInt(number_to_string) == 3)
        return 'Third'
    if (parseInt(number_to_string) == 4)
        return 'Fourth'
}

function challan_table_details(challan_details) {
    let particular_details = []
    let challan_element_details = []
    let challan_header = []
    let challan_total_amount = []
    let counter = 0
    let total_amount = 0.0
    for (var challan_element = 0; challan_element < challan_details.length; challan_element++) {
        var si_no = challan_element + 1
        if (counter == 0) {
            challan_header = [{
                    text: '#',
                    style: 'md_text_center_row'
                },
                {
                    text: 'Particulars',
                    style: 'md_text_center_row'
                },
                {
                    text: 'A/C No.',
                    style: 'md_text_center_row'
                },
                {
                    text: 'Amount',
                    style: 'md_text_center_row'
                }
            ]
            particular_details.push(challan_header)
            counter++
        }
        challan_header = [{
                text: si_no,
                style: 'sm_text_left'
            },
            {
                text: challan_details[challan_element]['particulars'],
                style: 'sm_text_left'
            },
            {
                text: challan_details[challan_element]['account_number'],
                style: 'sm_text_left'
            },
            {
                text: parseFloat(challan_details[challan_element]['amount']).toFixed(2),
                style: 'sm_text_right'
            }
        ]
        particular_details.push(challan_header)
        total_amount = parseFloat(parseFloat(total_amount) + parseFloat(challan_details[challan_element]['amount'])).toFixed(2);
    }

    challan_total_amount = [{
            text: 'TOTAL Rs. - ',
            style: 'sm_text_right_row',
            colSpan: 3
        },
        {
            text: '',
            style: 'sm_text_right_row',
            colSpan: 1
        },
        {
            text: '',
            style: 'sm_text_right_row',
            colSpan: 1
        },
        {
            text: total_amount,
            style: 'sm_text_right_row',
            colSpan: 1
        }
    ]
    particular_details.push(challan_total_amount)
    return particular_details
}

function fetch_payment(full_name, usn, program, program_level, payment_details, institute_details) {

    console.log(institute_details);
}

function generate_challan(full_name, usn, program, program_level, academic_year, payment_details,
    institute_details, default_val = 0) {
    // Local Variables

    if (default_val == 1)
        latest_records = latest_records
    else
        latest_records = payment_details;
    program_level = program_level;
    challan_id = latest_records['challan_number'];
    purpose = latest_records['challan_purpose']
    bank_name_id = latest_records['bank_name']
    bank_name = latest_records['bank_name']
    bank_address = latest_records['address']
    bank_city = latest_records['bank_name']
    // let bank_name = '',
    //     bank_address = '',
    //     bank_city = ''
    // for (var bank_element = 0; bank_element < bank_choices.length; bank_element++) {
    //     if (bank_choices[bank_element]['id'] == bank_name_id) {
    //         bank_name = bank_choices[bank_element]['bank_name'];
    //         bank_address = bank_choices[bank_element]['bank_branch'];
    //         bank_city = bank_choices[bank_element]['bank_city'];
    //     }
    // }
    // bank_name = bank_name.toUpperCase();
    // institute_details = JSON.parse(institute_details);
    // mess_member_details = JSON.parse(mess_member_details);
    let institute_name = institute_details[0]['name'];
    let institute_city = institute_details[0]['city']
    let institute_referer = institute_details[0]['referrer']
    var today = get_current_day();
    challan_details = latest_records['payment_details'];
    particular_details_original = challan_table_details(challan_details);
    particular_details_duplicate = challan_table_details(challan_details);
    particular_details_triplicate = challan_table_details(challan_details);
    particular_details_quadruplicate = challan_table_details(challan_details);
    let amount = 0.0;
    for (var challan_element = 0; challan_element < challan_details.length; challan_element++) {
        amount = amount + parseFloat(challan_details[challan_element]['amount']);
    }
    amount = inWords(String(amount));
    let docDefinition = {
        pageSize: 'A4',
        pageMargins: [1, 1, 1, 1],
        pageOrientation: 'portrait',
        content: [{
                style: 'md_text_center',
                stack: [{
                    columns: [{
                            table: {
                                widths: [268],
                                body: [
                                    [{
                                        border: [false],
                                        style: 'hostel_name_header',
                                        stack: [
                                            String(latest_records['department']).toUpperCase(),
                                        ]
                                    }],
                                    [{
                                        style: 'header',
                                        stack: [
                                            'ORIGINAL',
                                            {
                                                style: 'sm_text_center',
                                                text: institute_name.toUpperCase() + ', ' + institute_city.toUpperCase(),

                                            },
                                            {
                                                style: 'sm_text_left',
                                                text: 'Academic Year : ' + academic_year

                                            },
                                            {
                                                style: 'sm_text_left',
                                                text: 'Challan No. : \t\t\t\t\t\t\t\t\t\t\t\t' + 'SI No. : ' + challan_id
                                            }
                                        ]
                                    }],
                                    [{
                                        style: 'lg_text_center',
                                        stack: [
                                            bank_name.toUpperCase() + ',\n' + bank_address + ', ' + bank_city + '.\n',

                                            {

                                                text: [{
                                                        style: 'lg_text_center',
                                                        text: 'S. B. Account PAY-IN-SLIP'.toUpperCase() + '\n',
                                                    },
                                                    {
                                                        text: 'L. F. \t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t  Date : ' + today + '\n',
                                                        alignment: 'left'
                                                    },
                                                    {
                                                        text: institute_referer + ', ' + institute_name + ', ' + institute_city + '\n',
                                                        alignment: 'center'
                                                    },
                                                    {
                                                        text: 'Name of Remitter :  ',
                                                        alignment: 'left',
                                                        bold: false
                                                    },
                                                    {
                                                        text: full_name + '\n',
                                                        alignment: 'left',
                                                        bold: true,
                                                        lineGap: 20
                                                    },
                                                    {
                                                        text: 'Year :  ',
                                                        alignment: 'left',
                                                        bold: false,
                                                        lineGap: 20
                                                    },
                                                    {
                                                        text: program_level,
                                                        alignment: 'left',
                                                        bold: true,
                                                        lineGap: 20
                                                    },
                                                    {
                                                        text: '\t\t\t Branch: ',
                                                        alignment: 'left',
                                                        bold: false,
                                                        lineGap: 20
                                                    },
                                                    {
                                                        text: program + ' \n ',
                                                        alignment: 'left',
                                                        bold: true,
                                                        lineGap: 20
                                                    },
                                                    {
                                                        text: 'USN  :  ',
                                                        alignment: 'left',
                                                        bold: false
                                                    },
                                                    {
                                                        text: usn + '\n',
                                                        alignment: 'left',
                                                        bold: true,
                                                        lineGap: 20
                                                    }

                                                ],

                                            }
                                        ]
                                    }],
                                    [{
                                        style: 'sm_text_center',
                                        stack: [{
                                                text: [{
                                                    text: '( To be retained at the Bank)',
                                                    bold: false
                                                }]
                                            },
                                            {
                                                style: 'particular_details',
                                                text: '\n',
                                                table: {
                                                    widths: [15, 100, 70, 50],
                                                    body: particular_details_original

                                                },
                                                layout: {
                                                    hLineColor: function (i, node) {
                                                        return (i === 0 || i == 1 || i === node.table.body.length || i === node.table.body.length - 1) ? 'black' : 'gray';
                                                    },
                                                    vLineColor: function (i, node) {
                                                        return (i === 0 || i == 1 || i === node.table.widths.length) ? 'black' : 'gray';
                                                    },
                                                    // paddingLeft: function(i, node) { return 4; },
                                                    // paddingRight: function(i, node) { return 4; },
                                                    // paddingTop: function(i, node) { return 2; },
                                                    // paddingBottom: function(i, node) { return 2; },
                                                    // fillColor: function (i, node) { return null; }
                                                }
                                            },

                                            {
                                                text: [{
                                                        text: '\nRupees (in words) :  ' + amount.toLocaleUpperCase() + '\n\n',
                                                        alignment: 'left',
                                                    },
                                                    {
                                                        text: '\n(Signature of Remitter) \t\t ( Manager ) \t\t ( Cashier )',
                                                        alignment: 'left',
                                                        bold: false,

                                                    },
                                                ]
                                            }
                                        ],

                                    }]
                                ]
                            }
                        },
                        {
                            table: {
                                widths: [268],
                                body: [
                                    [{
                                        border: [false],
                                        style: 'hostel_name_header',
                                        stack: [
                                            String(latest_records['department']).toUpperCase(),
                                        ]
                                    }],
                                    [{
                                        style: 'header',
                                        stack: [
                                            'DUPLICATE',
                                            {
                                                style: 'sm_text_center',
                                                text: institute_name.toUpperCase() + ', ' + institute_city.toUpperCase(),

                                            },
                                            {
                                                style: 'sm_text_left',
                                                text: 'Admission Year : ' + academic_year

                                            }, {
                                                style: 'sm_text_left',
                                                text: 'Challan No. : \t\t\t\t\t\t\t\t\t\t\t\t\t\t\t' + 'SI No. : ' + challan_id
                                            }
                                        ]
                                    }],
                                    [{
                                        style: 'lg_text_center',
                                        stack: [
                                            bank_name.toUpperCase() + ',\n' + bank_address + ', ' + bank_city + '.\n',

                                            {

                                                text: [{
                                                        style: 'lg_text_center',
                                                        text: 'S. B. Account PAY-IN-SLIP'.toUpperCase() + '\n',
                                                    },
                                                    {
                                                        text: 'L. F. \t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t  Date : ' + today + '\n',
                                                        alignment: 'left'
                                                    },
                                                    {
                                                        text: institute_referer + ', ' + institute_name + ', ' + institute_city + '\n',
                                                        alignment: 'center'
                                                    },
                                                    {
                                                        text: 'Name of Remitter :  ',
                                                        alignment: 'left',
                                                        bold: false
                                                    },
                                                    {
                                                        text: full_name + '\n',
                                                        alignment: 'left',
                                                        bold: true,
                                                        lineGap: 20
                                                    },
                                                    {
                                                        text: 'Year :  ',
                                                        alignment: 'left',
                                                        bold: false,
                                                        lineGap: 20
                                                    },
                                                    {
                                                        text: program_level,
                                                        alignment: 'left',
                                                        bold: true,
                                                        lineGap: 20
                                                    },
                                                    {
                                                        text: '\t\t\t Branch: ',
                                                        alignment: 'left',
                                                        bold: false,
                                                        lineGap: 20
                                                    },
                                                    {
                                                        text: program + ' \n ',
                                                        alignment: 'left',
                                                        bold: true,
                                                        lineGap: 20
                                                    },
                                                    {
                                                        text: 'USN  :  ',
                                                        alignment: 'left',
                                                        bold: false
                                                    },
                                                    {
                                                        text: usn + '\n',
                                                        alignment: 'left',
                                                        bold: true,
                                                        lineGap: 20
                                                    }

                                                ],

                                            }
                                        ]
                                    }],
                                    [{
                                        style: 'sm_text_center',
                                        stack: [{
                                                text: [{
                                                    text: '( To be sent to the ' + institute_referer + ', ' + institute_name + ', ' + institute_city + ' through Bank)',
                                                    bold: false
                                                }]
                                            },
                                            {
                                                style: 'particular_details',
                                                text: '\n',
                                                table: {
                                                    widths: [15, 100, 70, 50],
                                                    body: particular_details_duplicate
                                                },
                                                layout: {
                                                    hLineColor: function (i, node) {
                                                        return (i === 0 || i == 1 || i === node.table.body.length || i === node.table.body.length - 1) ? 'black' : 'gray';
                                                    },
                                                    vLineColor: function (i, node) {
                                                        return (i === 0 || i == 1 || i === node.table.widths.length) ? 'black' : 'gray';
                                                    },
                                                    // paddingLeft: function(i, node) { return 4; },
                                                    // paddingRight: function(i, node) { return 4; },
                                                    // paddingTop: function(i, node) { return 2; },
                                                    // paddingBottom: function(i, node) { return 2; },
                                                    // fillColor: function (i, node) { return null; }
                                                }
                                            },

                                            {
                                                text: [{
                                                        text: '\nRupees (in words) :  ' + amount.toLocaleUpperCase() + '\n\n',
                                                        alignment: 'left',
                                                    },
                                                    {
                                                        text: '\n(Signature of Remitter) \t\t ( Manager ) \t\t ( Cashier )',
                                                        alignment: 'left',
                                                        bold: false,

                                                    },
                                                ]
                                            }
                                        ],

                                    }]
                                ]
                            }
                        },
                    ],
                    columnGap: 15,


                }],
                margin: [10, 15],

            },
            {
                stack: [{
                    columns: [{
                            table: {
                                widths: [268],
                                body: [
                                    [{
                                        border: [false],
                                        style: 'hostel_name_header',
                                        stack: [
                                            String(latest_records['department']).toUpperCase(),
                                        ]
                                    }],
                                    [{
                                        style: 'header',
                                        stack: [
                                            'TRIPLICATE',
                                            {
                                                style: 'sm_text_center',
                                                text: institute_name.toUpperCase() + ', ' + institute_city.toUpperCase(),

                                            },
                                            {
                                                style: 'sm_text_left',
                                                text: 'Admission Year : ' + academic_year

                                            }, {
                                                style: 'sm_text_left',
                                                text: 'Challan No. : \t\t\t\t\t\t\t\t\t\t\t\t\t\t\t' + 'SI No. : ' + challan_id
                                            }
                                        ]
                                    }],
                                    [{
                                        style: 'lg_text_center',
                                        stack: [
                                            bank_name.toUpperCase() + ',\n' + bank_address + ', ' + bank_city + '.\n',

                                            {

                                                text: [{
                                                        style: 'lg_text_center',
                                                        text: 'S. B. Account PAY-IN-SLIP'.toUpperCase() + '\n',
                                                    },
                                                    {
                                                        text: 'L. F. \t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t  Date : ' + today + '\n',
                                                        alignment: 'left'
                                                    },
                                                    {
                                                        text: institute_referer + ', ' + institute_name + ', ' + institute_city + '\n',
                                                        alignment: 'center'
                                                    },
                                                    {
                                                        text: 'Name of Remitter :  ',
                                                        alignment: 'left',
                                                        bold: false
                                                    },
                                                    {
                                                        text: full_name + '\n',
                                                        alignment: 'left',
                                                        bold: true,
                                                        lineGap: 20
                                                    },
                                                    {
                                                        text: 'Year :  ',
                                                        alignment: 'left',
                                                        bold: false,
                                                        lineGap: 20
                                                    },
                                                    {
                                                        text: program_level,
                                                        alignment: 'left',
                                                        bold: true,
                                                        lineGap: 20
                                                    },
                                                    {
                                                        text: '\t\t\t Branch: ',
                                                        alignment: 'left',
                                                        bold: false,
                                                        lineGap: 20
                                                    },
                                                    {
                                                        text: program + ' \n ',
                                                        alignment: 'left',
                                                        bold: true,
                                                        lineGap: 20
                                                    },
                                                    {
                                                        text: 'USN  :  ',
                                                        alignment: 'left',
                                                        bold: false
                                                    },
                                                    {
                                                        text: usn + '\n',
                                                        alignment: 'left',
                                                        bold: true,
                                                        lineGap: 20
                                                    }

                                                ],

                                            }
                                        ]
                                    }],
                                    [{
                                        style: 'sm_text_center',
                                        stack: [{
                                                text: [{
                                                    text: '( To be sent to the ' + institute_referer + ', ' + institute_name + ', ' + institute_city + ' by the Remitter)',
                                                    bold: false
                                                }]
                                            },
                                            {
                                                style: 'particular_details',
                                                text: '\n',
                                                table: {
                                                    widths: [15, 100, 70, 50],
                                                    body: particular_details_triplicate

                                                },
                                                layout: {
                                                    hLineColor: function (i, node) {
                                                        return (i === 0 || i == 1 || i === node.table.body.length || i === node.table.body.length - 1) ? 'black' : 'gray';
                                                    },
                                                    vLineColor: function (i, node) {
                                                        return (i === 0 || i == 1 || i === node.table.widths.length) ? 'black' : 'gray';
                                                    },
                                                    // paddingLeft: function(i, node) { return 4; },
                                                    // paddingRight: function(i, node) { return 4; },
                                                    // paddingTop: function(i, node) { return 2; },
                                                    // paddingBottom: function(i, node) { return 2; },
                                                    // fillColor: function (i, node) { return null; }
                                                }
                                            },

                                            {
                                                text: [{
                                                        text: '\nRupees (in words) :  ' + amount.toLocaleUpperCase() + '\n\n',
                                                        alignment: 'left',
                                                        bold: true,
                                                    },
                                                    {
                                                        text: '\n(Signature of Remitter) \t\t ( Manager ) \t\t ( Cashier )',
                                                        alignment: 'left',
                                                        bold: false,

                                                    },
                                                ]
                                            }
                                        ],

                                    }]
                                ]
                            }
                        },
                        {
                            table: {
                                widths: [268],
                                body: [
                                    [{
                                        border: [false],
                                        style: 'hostel_name_header',
                                        stack: [
                                            String(latest_records['department']).toUpperCase(),
                                        ]
                                    }],
                                    [{
                                        style: 'header',
                                        stack: [
                                            'QUADRUPLICATE',
                                            {
                                                style: 'sm_text_center',
                                                text: institute_name.toUpperCase() + ', ' + institute_city.toUpperCase(),

                                            },
                                            {
                                                style: 'sm_text_left',
                                                text: 'Admission Year : ' + academic_year

                                            }, {
                                                style: 'sm_text_left',
                                                text: 'Challan No. : \t\t\t\t\t\t\t\t\t\t\t\t\t\t\t' + 'SI No. : ' + challan_id
                                            }
                                        ]
                                    }],
                                    [{
                                        style: 'lg_text_center_last_record',
                                        stack: [
                                            bank_name.toUpperCase() + ',\n' + bank_address + ', ' + bank_city + '.\n',
                                            {
                                                text: [{
                                                        style: 'lg_text_center',
                                                        text: 'S. B. Account PAY-IN-SLIP'.toUpperCase() + '\n',
                                                    },
                                                    {
                                                        text: 'L. F. \t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t  Date : ' + today + '\n',
                                                        alignment: 'left'
                                                    },
                                                    {
                                                        text: institute_referer + ', ' + institute_name + ', ' + institute_city + '\n',
                                                        alignment: 'center'
                                                    },
                                                    {
                                                        text: 'Name of Remitter :  ',
                                                        alignment: 'left',
                                                        bold: false
                                                    },
                                                    {
                                                        text: full_name + '\n',
                                                        alignment: 'left',
                                                        bold: true,
                                                        lineGap: 20
                                                    },
                                                    {
                                                        text: 'Year :  ',
                                                        alignment: 'left',
                                                        bold: false,
                                                        lineGap: 20
                                                    },
                                                    {
                                                        text: program_level,
                                                        alignment: 'left',
                                                        bold: true,
                                                        lineGap: 20
                                                    },
                                                    {
                                                        text: '\t\t\t Branch: ',
                                                        alignment: 'left',
                                                        bold: false,
                                                        lineGap: 20
                                                    },
                                                    {
                                                        text: program + ' \n ',
                                                        alignment: 'left',
                                                        bold: true,
                                                        lineGap: 20
                                                    },
                                                    {
                                                        text: 'USN  :  ',
                                                        alignment: 'left',
                                                        bold: false
                                                    },
                                                    {
                                                        text: usn + '\n',
                                                        alignment: 'left',
                                                        bold: true,
                                                        lineGap: 20
                                                    }

                                                ],

                                            }
                                        ]
                                    }],
                                    [{
                                        style: 'sm_text_center',
                                        stack: [{
                                                text: [{
                                                    text: '( To be issued to the Remitter)\n ',
                                                    bold: false
                                                }]
                                            },
                                            {
                                                style: 'particular_details',
                                                text: '\n',
                                                table: {
                                                    widths: [15, 100, 70, 50],
                                                    body: particular_details_quadruplicate
                                                },
                                                layout: {
                                                    hLineColor: function (i, node) {
                                                        return (i === 0 || i == 1 || i === node.table.body.length || i === node.table.body.length - 1) ? 'black' : 'gray';
                                                    },
                                                    vLineColor: function (i, node) {
                                                        return (i === 0 || i == 1 || i === node.table.widths.length) ? 'black' : 'gray';
                                                    },
                                                    // paddingLeft: function(i, node) { return 4; },
                                                    // paddingRight: function(i, node) { return 4; },
                                                    // paddingTop: function(i, node) { return 2; },
                                                    // paddingBottom: function(i, node) { return 2; },
                                                    // fillColor: function (i, node) { return null; }
                                                }
                                            },

                                            {
                                                text: [{
                                                        text: '\nRupees (in words) :  ' + amount.toLocaleUpperCase() + '\n\n',
                                                        alignment: 'left',
                                                        bold: true
                                                    },
                                                    {
                                                        text: '\n(Signature of Remitter) \t\t ( Manager ) \t\t ( Cashier )',
                                                        alignment: 'left',
                                                        bold: false,

                                                    },
                                                ]
                                            }
                                        ],

                                    }]
                                ]
                            }
                        },
                    ],
                    columnGap: 15,


                }],
                margin: [10, 15],
            }
        ],
        styles: {
            hostel_name_header: {
                fontSize: 12,
                bold: true,
                alignment: 'center'
            },
            header: {
                fontSize: 10,
                bold: true,
                alignment: 'center'
            },
            lg_text_center: {
                fontSize: 10,
                bold: true,
                alignment: 'center',
                lineHeight: 1.25
            },
            lg_text_center_last_record: {
                fontSize: 10,
                bold: true,
                alignment: 'center',
                lineHeight: 1.25
            },
            md_text_center: {
                fontSize: 10,
                bold: true,
                alignment: 'center',
            },
            md_text_center_row: {
                fontSize: 10,
                bold: true,
                alignment: 'center',
                lineHeight: 1.2
            },
            sm_text_left: {
                fontSize: 10,
                alignment: 'left',
                lineGap: 3
            },
            sm_text_left_row: {
                fontSize: 10,
                alignment: 'left',
                lineHeight: 1.2
            },
            sm_text_right: {
                fontSize: 10,
                alignment: 'right'
            },
            sm_text_right_row: {
                fontSize: 10,
                alignment: 'right',
                lineHeight: 1.2
            },
            sm_text_center: {
                fontSize: 10,
                alignment: 'center'
            },
            particular_details: {
                fontSize: 10,
                alignment: 'left'
            }
        }
    };

    pdfMake.createPdf(docDefinition).open();
}


// Method to generate the print file for Guest Bill
function generate_guest_mess_bill(guest_bill_details, institute_details) {
    // Local Variables
    guest_bill_details = parse_template_to_json(guest_bill_details);
    institute_details = parse_template_to_json(institute_details);
    institute_name = institute_details[0]['name'];
    institute_city = institute_details[0]['city'];
    current_date = guest_bill_details['bill_date'];
    console.log(guest_bill_details);
    department_name = guest_bill_details['department'];
    let guest_bill_header = [];
    let guest_bill_content = [];
    let guest_bill = [];
    guest_bill_header = [{
        text: 'Total Members',
        style: 'sm_text_left'
    }, {
        text: 'Price/Meal',
        style: 'sm_text_left'
    }, {
        text: 'Total Amount',
        style: 'sm_text_left'
    }];
    guest_bill.push(guest_bill_header);
    guest_bill_content = [{
        text: guest_bill_details['total_members'],
        style: 'sm_text_left'
    }, {
        text: parseFloat(guest_bill_details['amount_per_meal']).toFixed(2),
        style: 'sm_text_left'
    }, {
        text: parseFloat(guest_bill_details['total_amount']).toFixed(2),
        style: 'sm_text_right'
    }];
    guest_bill.push(guest_bill_content);
    let docDefinition = {
        pageSize: 'A7',
        pageMargins: [1, 1, 1, 1],
        pageOrientation: 'portrait',
        content: [{
            style: 'md_text_center',
            stack: [{
                columns: [{
                    table: {
                        widths: ['*'],
                        body: [
                            [{
                                style: 'header',
                                stack: [
                                    'MESS BILL',
                                    {
                                        style: 'sm_text_center',
                                        text: institute_name.toUpperCase() + ', ' + institute_city.toUpperCase(),

                                    },
                                    {
                                        style: 'sm_text_left',
                                        text: 'Bill No. : ' + guest_bill_details['id'] + '\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t' + 'SI No. : '
                                    }
                                ]
                            }],
                            [{
                                style: 'lg_text_center',
                                stack: [
                                    '======== GUEST MESS BILL DETAILS ========\n',
                                    {
                                        table: {
                                            widths: ['*', '*'],
                                            body: [
                                                [{
                                                    text: 'Department: ' + department_name,
                                                    style: 'sm_text_left'
                                                }, {
                                                    text: 'Date: ' + current_date,
                                                    style: 'sm_text_right'
                                                }],
                                            ]
                                        },
                                        layout: 'noBorders'
                                    },
                                    {
                                        table: {
                                            widths: ['*', '*', '*'],
                                            body: guest_bill
                                        },
                                        layout: {
                                            hLineColor: function (i, node) {
                                                return (i === 0 || i == 1 || i === node.table.body.length || i === node.table.body.length - 1) ? 'black' : 'gray';
                                            },
                                            vLineColor: function (i, node) {
                                                return (i === 0 || i == 1 || i === node.table.widths.length) ? 'black' : 'gray';
                                            },
                                            // paddingLeft: function(i, node) { return 4; },
                                            // paddingRight: function(i, node) { return 4; },
                                            // paddingTop: function(i, node) { return 2; },
                                            // paddingBottom: function(i, node) { return 2; },
                                            // fillColor: function (i, node) { return null; }
                                        }
                                    },
                                    {

                                        text: [{
                                                text: '\n',
                                                alignment: 'left',
                                                lineGap: 20
                                            },

                                        ],

                                    },
                                ]
                            }],
                        ]
                    }
                }, ],
                columnGap: 15,


            }],
            margin: [10, 15],

        }, ],
        styles: {
            hostel_name_header: {
                fontSize: 6,
                bold: true,
                alignment: 'center'
            },
            header: {
                fontSize: 5,
                bold: true,
                alignment: 'center'
            },
            lg_text_center: {
                fontSize: 5,
                bold: true,
                alignment: 'center',
                lineHeight: 1.25
            },
            lg_text_center_last_record: {
                fontSize: 5,
                bold: true,
                alignment: 'center',
                lineHeight: 1.25
            },
            md_text_center: {
                fontSize: 5,
                bold: true,
                alignment: 'center',
            },
            md_text_center_row: {
                fontSize: 5,
                bold: true,
                alignment: 'center',
                lineHeight: 1.2
            },
            sm_text_left: {
                fontSize: 5,
                alignment: 'left',
                lineGap: 3
            },
            sm_text_left_row: {
                fontSize: 5,
                alignment: 'left',
                lineHeight: 1.2
            },
            sm_text_right: {
                fontSize: 5,
                alignment: 'right',
                lineGap: 3
            },
            sm_text_right_row: {
                fontSize: 5,
                alignment: 'right',
                lineHeight: 1.2
            },
            sm_text_center: {
                fontSize: 5,
                alignment: 'center'
            },
            particular_details: {
                fontSize: 5,
                alignment: 'left'
            }
        }
    };

    pdfMake.createPdf(docDefinition).open();
}