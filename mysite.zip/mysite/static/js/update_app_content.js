// Method to parse the content to JSON format
function parse_template_to_json(template_content) {
    template_content = template_content.replace(/None/g, "\'None\'");
    template_content = template_content.replace(/'/g, "\"");
    return JSON.parse(template_content);
}

function edit_institute(institute_details) {
    var media_path = '/media/';
    var static_path = '/static/'
    institute_details = parse_template_to_json(institute_details);
    $('#edit_institute').val(institute_details['id']);
    $('#name').val(institute_details['name']);
    $('#city').val(institute_details['city']);
    $('#address').val(institute_details['address']);
    $('#contact_number').val(institute_details['contact_number']);
    $('#emailid').val(institute_details['emailid']);
    $('#referrer').val(institute_details['referrer']);
    if (String(institute_details['logo']).includes('default_image')) {
        $('.organization_img')[0].src = static_path + institute_details['logo'];
    } else {
        $('.organization_img')[0].src = media_path + institute_details['logo'];
    }

}

function edit_department(department_details) {
    department_details = parse_template_to_json(department_details);
    $('#edit_department').val(department_details['id']);
    $('#name').val(department_details['name']);
    $('#acronym').val(department_details['acronym']);
    $('#city').val(department_details['city']);
    $('#address').val(department_details['address']);
    $('#details').val(department_details['details']);
    $('#serving_capacity').val(department_details['serving_capacity']);
    $('#department_type').val(department_details['department_type']);
    $('#department_type').selectpicker('refresh');
    $('#parent_department').val(department_details['parent_department']);
    $('#parent_department').selectpicker('refresh');
}

function edit_department_bank(department_bank_details) {
    department_bank_details = parse_template_to_json(department_bank_details);
    $('#edit_department_bank').val(department_bank_details['id']);
    $('#bank_name').val(department_bank_details['bank_name']);
    $('#branch').val(department_bank_details['branch']);
    $('#account_number').val(department_bank_details['account_number']);
    $('#ifsc_code').val(department_bank_details['ifsc_code']);
    $('#account_type').val(department_bank_details['account_type']);
    $('#account_type').selectpicker('refresh');
    $('#department').val(department_bank_details['department']);
    $('#department').selectpicker('refresh');
}

function edit_department_building(department_building_details) {
    department_building_details = parse_template_to_json(department_building_details);
    $('#edit_department_building').val(department_building_details['id']);
    $('#building_name').val(department_building_details['building_name']);
    $('#building_location').val(department_building_details['building_location']);
    $('#number_of_floors').val(department_building_details['number_of_floors']);
    $('#number_of_rooms').val(department_building_details['number_of_rooms']);
    $('#total_capacity').val(department_building_details['total_capacity']);
    $('#department').val(department_building_details['department']);
    $('#department').selectpicker('refresh');
}

function edit_supplier(supplier_details) {
    var media_path = '/media/';
    var static_path = '/static/'
    supplier_details = parse_template_to_json(supplier_details);
    $('#edit_supplier').val(supplier_details['id']);
    $('#name').val(supplier_details['name']);
    $('#shop_name').val(supplier_details['shop_name']);
    $('#shop_address').val(supplier_details['shop_address']);
    $('#landmark').val(supplier_details['landmark']);
    $('#city').val(supplier_details['city']);
    $('#mobile_number').val(supplier_details['mobile_number']);
    $('#telephone').val(supplier_details['telephone']);
    $('#emailid').val(supplier_details['emailid']);
    $('#gst_number').val(supplier_details['gst_number']);
    $('#pan_number').val(supplier_details['pan_number']);
    $('#country').val(supplier_details['country']);
    $('#country').selectpicker('refresh');
    $('#state').val(supplier_details['state']);
    $('#state').selectpicker('refresh');
    if (String(supplier_details['image']).includes('default_image')) {
        $('.supplier_image')[0].src = static_path + supplier_details['image'];
    } else {
        $('.supplier_image')[0].src = media_path + supplier_details['image'];
    }
}



function edit_particular_type(particular_type_details) {
    particular_type_details = parse_template_to_json(particular_type_details);
    $('#edit_particular_type').val(particular_type_details['id']);
    $('#name').val(particular_type_details['name']);
    $('#description').val(particular_type_details['description']);
}

function edit_particulars(particulars_details) {
    var media_path = '/media/';
    var static_path = '/static/'
    particulars_details = parse_template_to_json(particulars_details);
    $('#edit_particulars').val(particulars_details['id']);
    $('#name').val(particulars_details['name']);
    $('#description').val(particulars_details['description']);
    $('#min_stock_level').val(particulars_details['min_stock_level']);
    $('#unit').val(particulars_details['unit']);
    $('#unit').selectpicker('refresh');
    $('#particular_type').val(particulars_details['particular_type']);
    $('#particular_type').selectpicker('refresh');
    if (String(particulars_details['image']).includes('default_image')) {
        $('.particulars_image')[0].src = static_path + particulars_details['image'];
    } else {
        $('.particulars_image')[0].src = media_path + particulars_details['image'];
    }
}

// Function to open the model for member payment related to Hostel and Mess Departments
function view_challan_modal(department_type, department_details, member_details) {
    department_details = parse_template_to_json(department_details);
    member_details = parse_template_to_json(member_details);
    $('.selectpicker.department').empty();
    $('.thead-payment').empty();
    $('.tbody-payment').empty();
    $('.tfoot-payment').empty();
    jQuery('#view_challan').click(function (e) {

        $('.modal-container').load(function (result) {
            $('#memberPaymentChallan').modal({
                show: true
            });
        });
    });
    for (var department_element = 0; department_element < department_details.length; department_element++) {
        if (String(department_details[department_element]['department_type']).toLowerCase() == department_type.toLowerCase()) {
            option_content = '<option value=' + department_details[department_element]['id'] +
                ' data-tokens = ' + department_details[department_element]['name'] + ' > ' +
                department_details[department_element]['name'] + '</option>';
            $('.selectpicker.department').append(option_content);
        }
    }

    $('.selectpicker.department').selectpicker('refresh');
    $('#card_title_content').text('Generate ' + department_type + ' Challan');
    $('#department_type').text(department_type + ' Name');
    $('#full_name').val(member_details['full_name']);
    $('#usn').val(member_details['usn']);
    $('#academic_year').val(member_details['academic_year']);
}


// Function to open the model for member payment related to Hostel and Mess Departments
function print_challan_modal(department_details, payment_details, institute_details) {

    department_details = parse_template_to_json(department_details);
    payment_details = parse_template_to_json(payment_details);
    console.log(payment_details);
    institute_details = parse_template_to_json(institute_details);
    if (payment_details['member_payment'].length == 0) {
        payment_result = document.getElementById('print_challan_' + payment_details['id']);
        payment_result.href = '#';
    } else {
        jQuery('#print_challan_' + payment_details['id']).click(function (e) {
            $('.modal-container').load(function (result) {
                $('#printPaymentChallan').modal({
                    show: true
                });
            });
        });
        var tbody = document.getElementsByClassName('tbody-print-payment')[0];
        var payment_count = 1;
        $('.tbody-print-payment').empty();
        for (var payment_element = 0; payment_element < payment_details['member_payment'].length; payment_element++) {
            var tbody_row = document.createElement("tr");
            var si_number = document.createElement("th");
            si_number.setAttribute('align', 'center');
            si_number.setAttribute('scope', 'row');
            var challan_number = document.createElement("td");
            challan_number.setAttribute('align', 'center');
            challan_number.innerHTML = payment_details['member_payment'][payment_element]['challan_number'];
            var full_name = document.createElement("td");
            full_name.innerHTML = payment_details['full_name'];
            var usn = document.createElement("td");
            usn.setAttribute('align', 'center');
            usn.innerHTML = payment_details['usn'];
            var program = document.createElement("td");
            program.setAttribute('align', 'center');
            program.innerHTML = payment_details['program'];
            var program_level = document.createElement("td");
            program_level.setAttribute('align', 'center');
            program_level.innerHTML = payment_details['program_level'];
            var challan = document.createElement("td");
            challan.setAttribute('align', 'center');
            var button_challan = document.createElement("button");
            button_challan.setAttribute('class', 'button-brown');
            button_challan.setAttribute('onclick', 'generate_challan(' +
                JSON.stringify(payment_details['full_name']) + ',' +
                JSON.stringify(payment_details['usn']) + ',' +
                JSON.stringify(payment_details['program']) + ',' +
                JSON.stringify(payment_details['program_level']) + ',' +
                JSON.stringify(payment_details['academic_year']) + ',' +
                JSON.stringify(payment_details['member_payment'][payment_element]) + ',' +
                JSON.stringify(institute_details) + ',' +
                ')');
            button_challan.innerHTML = 'Print';
            var verify = document.createElement("td");
            verify.setAttribute('align', 'center');
            var button_verify = document.createElement("button");
            button_verify.setAttribute('class', 'button-royalblue');
            button_verify.innerHTML = 'Verify';
            var discard = document.createElement("td");
            discard.setAttribute('align', 'center');
            var button_discard = document.createElement("button");
            button_discard.setAttribute('class', 'button-orangered');
            button_discard.innerHTML = 'Discard';
            tbody_row.appendChild(si_number);
            tbody_row.appendChild(challan_number);
            tbody_row.appendChild(full_name);
            tbody_row.appendChild(usn);
            tbody_row.appendChild(program);
            tbody_row.appendChild(program_level);
            challan.appendChild(button_challan);
            tbody_row.appendChild(challan);
            verify.appendChild(button_verify);
            tbody_row.appendChild(verify);
            discard.appendChild(button_discard);
            tbody_row.appendChild(discard);
            tbody.appendChild(tbody_row);
        }
        row_elements = tbody_row.childNodes;
        $(row_elements[7].childNodes[0]).click(function () {
            url = '/member/search'
            swal({
                title: 'Are you sure?',
                text: "You want to Approve #" + payment_details['member_payment'][0]['challan_number'] + " Challan",
                type: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, Allocate!'
            }).then((result) => {
                if (result.value) {
                    $.post(url, {
                        approve_challan_number: payment_details['member_payment'][0]['challan_number'],
                        csrfmiddlewaretoken: $('input[name="csrfmiddlewaretoken"]').val()
                    });
                    $.get(url, function (data, status) {
                        if (status == 'success') window.location = url;
                    });
                }
            });
        });

    }
    $('#print-payment-records').DataTable();


}

// Function to update the member attendance
function upload_member_attendance(member_records, start_date, end_date) {
    member_details = parse_template_to_json(member_records);
    $("#member_attendance_" + member_details['id']).click(function (e) {
        $('.modal-container').load(function (result) {
            $('#memberAttendance').modal({
                show: true
            });
        });
    });
    $('#full_name').val(member_details['full_name']);
    $('#usn').val(member_details['usn']);
    $('#edit_member_attendance').val(member_details['id']);
    let today = new Date().toISOString().slice(0, 10);
    $(start_date).val(today);
    $(end_date).val(today);
    set_calendar_dates('YYYY-MM-DD', 'days', start_date, member_details['member_academic_start_date'], member_details['member_academic_end_date']);
    set_calendar_dates('YYYY-MM-DD', 'days', end_date, member_details['member_academic_start_date'], member_details['member_academic_end_date']);

}

// Function to disable the calendar dates based on the academic year dates
function set_calendar_dates(date_format, view_mode, field_attribute, start_date, end_date) {
    $(field_attribute).datetimepicker({
        format: date_format,
        viewMode: view_mode,
        ignoreReadonly: true,
        minDate: start_date,
        maxDate: end_date
    });
    if (view_mode == 'years') {
        $(field_attribute).on("dp.change", function (e) {
            var formatedValue = e.date.format(e.date._f);
            current_year = formatedValue.split('-')[0]
            next_year = parseInt(current_year.substring(2)) + 1;
            $(field_attribute).val(current_year + '-' + next_year);
        });
    }
}
// Function to disable the calendar dates based on the academic year dates
function set_calendar_min_dates(date_format, view_mode, field_attribute, start_date) {
    $(field_attribute).datetimepicker({
        format: date_format,
        viewMode: view_mode,
        ignoreReadonly: true,
        minDate: start_date,
    });
    if (view_mode == 'years') {
        $(field_attribute).on("dp.change", function (e) {
            var formatedValue = e.date.format(e.date._f);
            current_year = formatedValue.split('-')[0]
            next_year = parseInt(current_year.substring(2)) + 1;
            $(field_attribute).val(current_year + '-' + next_year);
        });
    }
}
// Function to disable the calendar dates based on the academic year dates
function set_calendar_max_dates(date_format, view_mode, field_attribute, end_date) {
    $(field_attribute).datetimepicker({
        format: date_format,
        viewMode: view_mode,
        ignoreReadonly: true,
        maxDate: end_date,
    });
    if (view_mode == 'years') {
        $(field_attribute).on("dp.change", function (e) {
            var formatedValue = e.date.format(e.date._f);
            current_year = formatedValue.split('-')[0]
            next_year = parseInt(current_year.substring(2)) + 1;
            $(field_attribute).val(current_year + '-' + next_year);
        });
    }
}

// Function to update the select option values for the respective department
function selected_department_building(department_id, building_choices, field_attribute) {
    building_choices = parse_template_to_json(building_choices);
    $(field_attribute).empty();
    for (var building_element = 0; building_element < building_choices.length; building_element++) {
        if (building_choices[building_element]['department_id'] == department_id) {
            option_content = '<option value=' + building_choices[building_element]['id'] +
                ' data-tokens = ' + building_choices[building_element]['name'] + ' > ' +
                building_choices[building_element]['name'] + '</option>';
            $(field_attribute).append(option_content);
        }
    }
    $(field_attribute).selectpicker('refresh');
}

// Function to update the select option values for the respective building Floors
function selected_building_floor(building_id, building_choices, field_attribute) {
    building_choices = parse_template_to_json(building_choices);
    $(field_attribute).empty();
    for (var building_element = 0; building_element < building_choices.length; building_element++) {
        if (building_choices[building_element]['id'] == building_id) {
            building_floors = parseInt(building_choices[building_element]['number_of_floors']);
            for (var floor_number = 1; floor_number <= building_floors; floor_number++) {
                current_floor_number = ordinal_suffix(floor_number) + ' - Floor';
                option_content = ' <option value=' + floor_number + ' data-tokens="' +
                    current_floor_number + '">' + current_floor_number +
                    ' </option > ';
                $(field_attribute).append(option_content);
                $(field_attribute).selectpicker('refresh');
            }
        }
    }
}

// Function to update the select option values for the respective building room category
function selected_building_category(building_id, category_choices, field_attribute) {
    category_choices = parse_template_to_json(category_choices);
    $(field_attribute).empty();
    for (var category_element = 0; category_element < category_choices.length; category_element++) {
        if (category_choices[category_element]['building_id'] == building_id) {
            option_content = ' <option value=' + category_choices[category_element]['id'] + ' data-tokens=' +
                category_choices[category_element]['category'] + '>' + category_choices[category_element]['category'] +
                ' </option > ';
            $(field_attribute).append(option_content);
            $(field_attribute).selectpicker('refresh');
        }
    }
}

function ordinal_suffix(floor_number) {
    var first_comparer = floor_number % 10,
        second_comparer = floor_number % 100;
    if (first_comparer == 1 && second_comparer != 11) {
        return floor_number + "st";
    }
    if (first_comparer == 2 && second_comparer !=
        12) {
        return floor_number + "nd";
    }
    if (first_comparer == 3 && second_comparer != 13) {
        return floor_number + "rd";
    }
    return floor_number + "th";
}