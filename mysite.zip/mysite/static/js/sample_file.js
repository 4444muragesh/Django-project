function validate_password(field_id) {
    var password = document.getElementById(field_id);
    console.log(password.value);
}

function validate() {
    var password1 = document.getElementById("pwd").value;
    var confirmPassword = document.getElementById("cpwd").value;
    if (password1 != confirmPassword) {
        console.log("Passwords do not match.");
        return false;
    }
    return true;
}

function R_Select(field_name) {
    var radio = document.getElementsByName(field_name);
    if (radio[0].checked == true) {
        alert("Your gender is male");
    } else {
        alert("Your gender is female");
    }
}

function DD_Select() {
    var x = document.getElementById("select").selectedIndex;
    var y = document.getElementById("select").options;
    console.log("Index: " + y[x].index + " is " + y[x].text);
}


