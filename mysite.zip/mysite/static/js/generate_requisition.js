// Method to set the current date
function get_current_day() {
    // Current Date
    var today = new Date();
    var dd = today.getDate();
    var mm = today.getMonth() + 1; //January is 0!

    var yyyy = today.getFullYear();
    if (dd < 10) {
        dd = '0' + dd;
    }
    if (mm < 10) {
        mm = '0' + mm;
    }

    current_date = dd + '-' + mm + '-' + yyyy;
    return current_date;
}

// Method to parse the content to JSON format
function parse_template_to_json(template_content) {
    template_content = template_content.replace(/None/g, "\'None\'");
    template_content = template_content.replace(/'/g, "\"");
    return JSON.parse(template_content);
}

function generate_requisition(requisition_id, requisition_details, institute_details) {
    // Local Variables
    requisition_details = parse_template_to_json(requisition_details);
    institute_details = parse_template_to_json(institute_details);
    institute_name = institute_details[0]['name'];
    institute_city = institute_details[0]['city'];
    let req_id = '',
        department_name = '';
    let requisition_details_list = [],
        requisition_header = [],
        requisition_content = [];
    for (var requisition_element = 0; requisition_element < requisition_details.length; requisition_element++) {
        if (requisition_details[requisition_element]['id'] == requisition_id.childNodes[3].textContent) {
            current_element_length = requisition_details[requisition_element]['requisition_details'].length;
            var counter = 1;
            req_id = requisition_details[requisition_element]['id']
            department_name = requisition_details[requisition_element]['department']
            requisition_header = [{
                text: '#',
                style: 'md_text_center_row'
            }, {
                text: 'Particulars',
                style: 'sm_text_left'
            }, {
                text: 'Quantity',
                style: 'sm_text_left'
            }];
            requisition_details_list.push(requisition_header);
            for (var req_details_element = 0; req_details_element < current_element_length; req_details_element++) {
                particulars = requisition_details[requisition_element]['requisition_details'][req_details_element]['particulars'];
                quantity_requested = requisition_details[requisition_element]['requisition_details'][req_details_element]['quantity_requested'];
                quantity_supplied = requisition_details[requisition_element]['requisition_details'][req_details_element]['quantity_supplied'];
                unit = requisition_details[requisition_element]['requisition_details'][req_details_element]['unit'];
                requisition_content = [{
                    text: req_details_element + 1,
                    style: 'md_text_center_row'
                }, {
                    text: particulars,
                    style: 'sm_text_left'
                }, {
                    text: quantity_requested + '-' + unit,
                    style: 'sm_text_left'
                }];
                requisition_details_list.push(requisition_content);
            }
        }
    }
    current_date = get_current_day();
    let docDefinition = {
        pageSize: 'A7',
        pageMargins: [1, 1, 1, 1],
        pageOrientation: 'portrait',
        content: [{
            style: 'md_text_center',
            stack: [{
                columns: [{
                    table: {
                        widths: ['*'],
                        body: [
                            [{
                                style: 'header',
                                stack: [
                                    'REQUISITION',
                                    {
                                        style: 'sm_text_center',
                                        text: institute_name.toUpperCase() + ', ' + institute_city.toUpperCase(),

                                    },
                                    {
                                        style: 'sm_text_left',
                                        text: 'Req No. : ' + req_id + '\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t' + 'SI No. : '
                                    }
                                ]
                            }],
                            [{
                                style: 'lg_text_center',
                                stack: [
                                    '======== REQUISITION DETAILS ========\n',

                                    {

                                        text: [{
                                                text: 'Department : ' + department_name + '\t\t\t\t\t\t\t\t\t\t\t  Date : ' + current_date + '\n',
                                                alignment: 'left'
                                            },
                                            {
                                                text: '\n',
                                                alignment: 'left',
                                                lineGap: 20
                                            },

                                        ],

                                    },
                                    {
                                        table: {
                                            widths: ['*'],
                                            body: [
                                                [{
                                                    style: 'sm_text_center',
                                                    stack: [{
                                                            style: 'particular_details',
                                                            text: '\n',
                                                            table: {
                                                                widths: [5, '*', '*'],
                                                                body: requisition_details_list
                                                            },
                                                            layout: {
                                                                hLineColor: function (i, node) {
                                                                    return (i === 0 || i == 1 || i === node.table.body.length || i === node.table.body.length - 1) ? 'black' : 'gray';
                                                                },
                                                                vLineColor: function (i, node) {
                                                                    return (i === 0 || i == 1 || i === node.table.widths.length) ? 'black' : 'gray';
                                                                },
                                                                // paddingLeft: function(i, node) { return 4; },
                                                                // paddingRight: function(i, node) { return 4; },
                                                                // paddingTop: function(i, node) { return 2; },
                                                                // paddingBottom: function(i, node) { return 2; },
                                                                // fillColor: function (i, node) { return null; }
                                                            }
                                                        },

                                                        {
                                                            text: [{
                                                                    text: '\n\n\n\n',
                                                                    alignment: 'left',
                                                                },
                                                                {
                                                                    text: '( Signature of Manager ) ',
                                                                    alignment: 'right',
                                                                    bold: false,

                                                                },
                                                            ]
                                                        }
                                                    ],

                                                }]
                                            ]
                                        }
                                    },
                                ]
                            }],
                        ]
                    }
                }, ],
                columnGap: 15,


            }],
            margin: [10, 15],

        }, ],
        styles: {
            hostel_name_header: {
                fontSize: 6,
                bold: true,
                alignment: 'center'
            },
            header: {
                fontSize: 5,
                bold: true,
                alignment: 'center'
            },
            lg_text_center: {
                fontSize: 5,
                bold: true,
                alignment: 'center',
                lineHeight: 1.25
            },
            lg_text_center_last_record: {
                fontSize: 5,
                bold: true,
                alignment: 'center',
                lineHeight: 1.25
            },
            md_text_center: {
                fontSize: 5,
                bold: true,
                alignment: 'center',
            },
            md_text_center_row: {
                fontSize: 5,
                bold: true,
                alignment: 'center',
                lineHeight: 1.2
            },
            sm_text_left: {
                fontSize: 5,
                alignment: 'left',
                lineGap: 3
            },
            sm_text_left_row: {
                fontSize: 5,
                alignment: 'left',
                lineHeight: 1.2
            },
            sm_text_right: {
                fontSize: 5,
                alignment: 'right'
            },
            sm_text_right_row: {
                fontSize: 5,
                alignment: 'right',
                lineHeight: 1.2
            },
            sm_text_center: {
                fontSize: 5,
                alignment: 'center'
            },
            particular_details: {
                fontSize: 5,
                alignment: 'left'
            }
        }
    };

    pdfMake.createPdf(docDefinition).open();
}