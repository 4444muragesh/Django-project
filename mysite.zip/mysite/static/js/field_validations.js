// Method to validate the Mobile Numbers
function validate_mobile_numbers(field_attribute) {
    mobile_number_field = document.getElementById(field_attribute);
    $(mobile_number_field).mask('00000000000');
}


// Method to parse the content to JSON format
function parse_template_to_json(template_content) {
    template_content = template_content.replace(/None/g, "\'None\'");
    template_content = template_content.replace(/'/g, "\"");
    return JSON.parse(template_content);
}

function set_academic_year(date_format, view_mode, field_attribute) {
    $(field_attribute).datetimepicker({
        format: date_format,
        viewMode: view_mode,
        ignoreReadonly: true
    });
    if (view_mode == 'years') {
        $(field_attribute).on("dp.change", function (e) {
            var formatedValue = e.date.format(e.date._f);
            current_year = formatedValue.split('-')[0]
            next_year = parseInt(current_year.substring(2)) + 1;
            $(field_attribute).val(current_year + '-' + next_year);
        });
    }
}

function set_date(date_format, view_mode, field_attribute) {
    $(field_attribute).datetimepicker({
        format: date_format,
        viewMode: view_mode,
        ignoreReadonly: true
    });
    let today = new Date().toISOString().slice(0, 10);
    $(field_attribute).val(today);
    if (view_mode == 'years') {
        $(field_attribute).on("dp.change", function (e) {
            var formatedValue = e.date.format(e.date._f);
            current_year = formatedValue.split('-')[0]
            next_year = parseInt(current_year.substring(2)) + 1;
            $(field_attribute).val(current_year + '-' + next_year);
        });
    }
}


// Method to convert the text to uppercase
function convert_to_uppercase(tag_id) {
    $(document.getElementById(tag_id)).keyup(function () {
        this.value = this.value.toLocaleUpperCase();
    });
}
// Method to convert the text to capitalized text
function convert_to_capitalize(tag_id) {
    $(document.getElementById(tag_id)).keyup(function () {
        this.value = this.value.replace(/(^|\s)\S/g, l => l.toUpperCase());
    });
}

// Method to display the default options to be set
function set_default_select_value(tag_id, value, state_tag_id, state_default_value) {
    var select_options = document.getElementById(tag_id).options
    for (select_element = 0; select_element < select_options.length; select_element++) {
        if (select_options[select_element].text.toLowerCase() == value.toLowerCase()) {
            $('#' + tag_id).val(select_options[select_element].value);
            $('#' + tag_id).selectpicker('refresh')
        }
    }
    mapped_value = $('#' + tag_id).val();
    set_default_on_selected_value(state_tag_id, mapped_value, state_default_value);
}

function set_default_on_selected_value(tag_id, mapped_value, state_name) {
    var matching_states = $('#' + tag_id + '>option').filter(function () {
        return $(this).attr('data-mapping') == mapped_value;
    });
    mapped_state_value = ''
    for (var matching_element = 0; matching_element < matching_states.length; matching_element++) {
        if (matching_states[matching_element].text.toLowerCase() == state_name.toLowerCase()) {
            mapped_state_value = matching_states[matching_element].value
        }
    }
    $("#" + tag_id).children("option[data-mapping!=" + mapped_value + "]").hide();
    $("#" + tag_id).val($("#" + tag_id).children("option[data-mapping=" +
        mapped_value + " ] ").first().val());
    $('#' + tag_id).val(mapped_state_value);
    $('#' + tag_id).selectpicker('refresh');
    $("#" + tag_id).children("option[data-mapping]").show();
}

// Method to set the current date as default date
function get_current_date(field_attribute) {
    // Current Date
    var today = new Date();
    var dd = today.getDate();
    var mm = today.getMonth() + 1; //January is 0!

    var yyyy = today.getFullYear();
    if (dd < 10) {
        dd = '0' + dd;
    }
    if (mm < 10) {
        mm = '0' + mm;
    }
    current_date = document.getElementById(field_attribute);
    current_date.value = yyyy + '-' + mm + '-' + dd;
}


//Method to add dynamic row for invoices
var invoice_count = 1;
var invoice_table_head = 1;

function addRow(in_tbl_name, particular_choices, unit_choices) {
    particular_choices = parse_template_to_json(particular_choices);
    unit_choices = parse_template_to_json(unit_choices);
    if (invoice_table_head == 1) {
        invoice_table_head_content(in_tbl_name);
        invoice_table_body_content(in_tbl_name, particular_choices, unit_choices);
        invoice_table_head++;
    } else {
        invoice_table_body_content(in_tbl_name, particular_choices, unit_choices);
    }
}

//Method to create table head for invoices 
function invoice_table_head_content(in_tbl_name) {
    var thead = document.getElementById(in_tbl_name).getElementsByTagName("thead")[0];
    var thead_row = document.createElement("tr");
    thead_row.setAttribute('class', 'thead-invoice');
    var si_number = document.createElement("td");
    si_number.innerHTML = "SI No.";
    var particulars = document.createElement("td");
    particulars.innerHTML = "Particulars";
    var unit = document.createElement("td");
    unit.innerHTML = "Unit";
    var price_per_unit = document.createElement("td");
    price_per_unit.innerHTML = "Price/Unit";
    var supplied_quantity = document.createElement("td");
    supplied_quantity.innerHTML = "Quantity";
    var item_amount = document.createElement("td");
    item_amount.innerHTML = "Amount";
    var tax_percentage = document.createElement("td");
    tax_percentage.innerHTML = "Tax (%)";
    var tax_amount = document.createElement("td");
    tax_amount.innerHTML = "Tax Amount";
    var item_total_amount = document.createElement("td");
    item_total_amount.innerHTML = "Total Amount";
    var actions = document.createElement("td");
    actions.innerHTML = "Actions";
    thead_row.appendChild(si_number);
    thead_row.appendChild(particulars);
    thead_row.appendChild(unit);
    thead_row.appendChild(price_per_unit);
    thead_row.appendChild(supplied_quantity);
    thead_row.appendChild(item_amount);
    thead_row.appendChild(tax_percentage);
    thead_row.appendChild(tax_amount);
    thead_row.appendChild(item_total_amount);
    thead_row.appendChild(actions);
    thead.appendChild(thead_row);
}

//Method to create table body for invoices 
function invoice_table_body_content(in_tbl_name, particular_choices, unit_choices) {
    $('.no-borders').remove();
    invoice_count = invoice_count + 1;
    let total_amount = 0.0;
    let amount = 0.0
    var tbody = document.getElementById(in_tbl_name).getElementsByTagName("tbody")[0];
    var tbody_row = document.createElement("tr");
    var tfoot = document.getElementById(in_tbl_name).getElementsByTagName("tfoot")[0];
    var tfoot_row = document.createElement("tr");
    tbody_row.setAttribute('class', 'tbody-invoice');
    // create table cell for SI Number
    var si_number = document.createElement("th");
    si_number.setAttribute('align', 'center');
    si_number.setAttribute('scope', 'row');
    // var si_number_HTML = "<FONT SIZE=\"+1\">*</FONT>";
    // si_number.innerHTML = si_number_HTML.replace(/\*/g, invoice_count);
    // create table cell for Particulars
    var particulars = document.createElement("td");
    particulars.setAttribute('width', '15%');
    var particulars_HTML = ' <' +
        'select class="selectpicker particular_type" ' +
        ' name="particular_type" id="particular_type" ' +
        'data-live-search= "true"></select>';
    particulars.innerHTML = particulars_HTML.replace(/!invoice_count!/g, invoice_count);
    // create table cell for Unit
    var unit = document.createElement("td");
    unit.setAttribute('width', '15%');
    var unit_HTML = ' <' +
        'select class="selectpicker unit" ' +
        ' name="unit" id="unit" ' +
        'data-live-search= "true"></select>';
    unit.innerHTML = unit_HTML.replace(/!invoice_count!/g, invoice_count);
    // create table cell for price per unit
    var price_per_unit = document.createElement("td")
    var price_per_unit_HTML =
        ' <input type="number" class="form-control validate" name="price_per_unit" id="price_per_unit" min="0" step="0.01" value="0" required > ';
    price_per_unit.innerHTML = price_per_unit_HTML.replace(/!invoice_count!/g, invoice_count);
    // create table cell for supplied quantity
    var supplied_quantity = document.createElement("td")
    var supplied_quantity_HTML =
        ' <input type="number" class="form-control validate" name="supplied_quantity" id="supplied_quantity" min="0" step="0.01" value="0" required > ';
    supplied_quantity.innerHTML = supplied_quantity_HTML.replace(/!invoice_count!/g, invoice_count);
    // create table cell for Total Amount
    var item_amount = document.createElement("td")
    var amount_HTML =
        ' <input type="number" class="form-control validate item_amount" name="item_amount" id="item_amount" min="0" step="0.01" value="0" readonly > ';
    item_amount.innerHTML = amount_HTML.replace(/!invoice_count!/g, invoice_count);

    //Create table cell for tax percentage
    var tax_percentage = document.createElement("td");
    var tax_percentage_HTML =
        ' <input type="number" class="form-control validate" name="tax_percentage" id="tax_percentage" min="0" step="0.01" value="0" required > ';
    tax_percentage.innerHTML = tax_percentage_HTML.replace(/!invoice_count!/g, invoice_count);

    //Create table cell for tax amount
    var tax_amount = document.createElement("td")
    var tax_amount_HTML =
        ' <input type="number" class="form-control validate" name="tax_amount" id="tax_amount" min="0" step="0.01" value="0" readonly > ';
    tax_amount.innerHTML = tax_amount_HTML.replace(/!invoice_count!/g, invoice_count);

    //Create table cell for total amount
    var item_total_amount = document.createElement("td")
    var item_total_amount_HTML =
        ' <input type="number" class="form-control validate item_total_amount"  name="item_total_amount" id="item_total_amount" min="0" step="0.01" value="0" readonly > ';
    item_total_amount.innerHTML = item_total_amount_HTML.replace(/!invoice_count!/g, invoice_count);

    // create table cell for actions
    var actions = document.createElement("td");
    actions.setAttribute('width', '8%');
    var actions_HTML =
        ' <span class="add-remove-invoice-record"><button type="button" class="btn btn-primary btn-sm"><i class="fas fa-plus fa-2x aria-hidden="true"> </i></button>' +
        ' <button class="btn btn-danger btn-sm" onclick=delRow()><i class="fas fa-trash-alt fa-2x aria-hidden="true"> </i></button> </span>';
    actions.innerHTML = actions_HTML.replace(/!invoice_count!/g, invoice_count);
    tbody_row.appendChild(si_number);
    tbody_row.appendChild(particulars);
    tbody_row.appendChild(unit);
    tbody_row.appendChild(price_per_unit);
    tbody_row.appendChild(supplied_quantity);
    tbody_row.appendChild(item_amount);
    tbody_row.appendChild(tax_percentage);
    tbody_row.appendChild(tax_amount);
    tbody_row.appendChild(item_total_amount);
    tbody_row.appendChild(actions);
    tbody.appendChild(tbody_row);
    // var button_row = document.createElement("tr");
    // button_row.setAttribute('class', 'no-borders');
    // var btn = document.createElement("button");
    // btn.setAttribute('class', 'btn btn-primary float-right');
    // btn.setAttribute('type', 'submit');
    // var btn_text = document.createTextNode("Submit");
    // btn.appendChild(btn_text);
    // for (button_element = 0; button_element < 6; button_element++) {
    //     var button_col = document.createElement("td");
    //     button_row.appendChild(button_col);
    // }
    // var button_col = document.createElement("td");
    // button_row.appendChild(button_col);
    // button_col.appendChild(btn);
    // tbody.appendChild(button_row);
    if (tfoot.childElementCount == 0) {
        var tfoot_row = document.createElement("tr");
        var empty_col_1 = document.createElement("td");
        var empty_col_2 = document.createElement("td");
        var empty_col_3 = document.createElement("td");
        var empty_col_4 = document.createElement("td");
        var empty_col_5 = document.createElement("td");
        var empty_col_6 = document.createElement("td");
        var empty_col_7 = document.createElement("td");
        var empty_col_8 = document.createElement("td");
        var empty_col_9 = document.createElement("td");
        var total_label = document.createElement("label");
        total_label.innerHTML = 'Total Amount : ';
        empty_col_8.appendChild(total_label);
        var total_HTML =
            '<input type="number" class="form-control validate" name="total" id="total" min="0" step="0.01" value="0" readonly > ';
        empty_col_9.innerHTML = total_HTML;
        var submit = document.createElement("button");
        submit.setAttribute('type', 'submit');
        submit.setAttribute('class', 'btn btn-primary');
        submit.innerHTML = 'Submit';
        tfoot_row.appendChild(empty_col_1);
        tfoot_row.appendChild(empty_col_2);
        tfoot_row.appendChild(empty_col_3);
        tfoot_row.appendChild(empty_col_4);
        tfoot_row.appendChild(empty_col_5);
        tfoot_row.appendChild(empty_col_6);
        tfoot_row.appendChild(empty_col_7);
        tfoot_row.appendChild(empty_col_8);
        tfoot_row.appendChild(empty_col_9);
        tfoot_row.appendChild(submit);
        tfoot.appendChild(tfoot_row);
    }
    row_elements = tbody_row.childNodes;
    tfoot_row_elements = tfoot.childNodes;
    for (var particular_element = 0; particular_element < particular_choices.length; particular_element++) {
        option_content = '<option value=' + particular_choices[particular_element]['id'] + ' data-tokens="' +
            particular_choices[particular_element]['name'] + '">' + particular_choices[particular_element]
            ['name'] + '</option>';
        $(row_elements[1].childNodes[1]).append(option_content);
    }
    for (var unit_element = 0; unit_element < unit_choices.length; unit_element++) {
        option_content = ' <option value=' + unit_choices[unit_element] +
            ' data-tokens=' + unit_choices[unit_element] + '>' + unit_choices[unit_element] +
            '</option>';
        $(row_elements[2].childNodes[1]).append(option_content);
    }
    $(row_elements[3].childNodes[1]).keyup(function () {
        let supplied_qty = parseFloat($(row_elements[3].childNodes[1]).val());
        let price_per_unit = parseFloat($(row_elements[4].childNodes[1]).val());
        let tax_percentage = parseFloat($(row_elements[6].childNodes[1]).val());
        if (isNaN(supplied_qty) || isNaN(price_per_unit)) {
            tax_amount = 0.0;
            amount = 0.0
        } else {
            amount = price_per_unit * supplied_qty;
            if (isNaN(tax_percentage)) {
                tax_percentage = 0.0;
            } else {
                tax_percentage = tax_percentage / 100;
                tax_amount = (price_per_unit * supplied_qty) * tax_percentage;
            }
        }
        item_total_amount = amount + tax_amount;
        $(row_elements[7].childNodes[1]).val(parseFloat(tax_amount).toFixed(2));
        $(row_elements[5].childNodes[1]).val(parseFloat(amount).toFixed(2));
        $(row_elements[8].childNodes[1]).val(parseFloat(item_total_amount).toFixed(2));
        total_amount_input = $('.item_total_amount');
        total_amount = 0.0
        for (amount_input = 0; amount_input < total_amount_input.length; amount_input++) {
            total_amount = parseFloat(total_amount) + parseFloat(total_amount_input[amount_input].value);
        }
        final_total = parseFloat(total_amount);
        $(tfoot_row_elements[1].childNodes[8].childNodes[0]).val(parseFloat(final_total).toFixed(2));
    });
    let particular_id = $(row_elements[1].childNodes[1]).val();
    for (var particular_element = 0; particular_element < particular_choices.length; particular_element++) {
        if (particular_id == particular_choices[particular_element]['id']) {
            for (var unit_element = 0; unit_element < unit_choices.length; unit_element++) {
                if (String(particular_choices[particular_element]['unit']).toLowerCase() == String(unit_choices[unit_element]).toLowerCase()) {
                    $(row_elements[2].childNodes[1]).val(unit_choices[unit_element]);
                    $(row_elements[2].childNodes[1]).selectpicker('refresh');
                }
            }
        }
    }
    $(row_elements[1].childNodes[1]).on('change', function () {
        let particular_id = $(row_elements[1].childNodes[1].childNodes[2]).val();
        for (var particular_element = 0; particular_element < particular_choices.length; particular_element++) {
            if (particular_id == particular_choices[particular_element]['id']) {
                for (var unit_element = 0; unit_element < unit_choices.length; unit_element++) {
                    if (String(particular_choices[particular_element]['unit']).toLowerCase() == String(unit_choices[unit_element]).toLowerCase()) {
                        $(row_elements[2].childNodes[1].childNodes[2]).val(unit_choices[unit_element]);
                        $(row_elements[2].childNodes[1].childNodes[2]).selectpicker('refresh');
                    }
                }
            }
        }
    });
    $(row_elements[4].childNodes[1]).keyup(function () {

        let supplied_qty = parseFloat($(row_elements[3].childNodes[1]).val());
        let price_per_unit = parseFloat($(row_elements[4].childNodes[1]).val());
        let tax_percentage = parseFloat($(row_elements[6].childNodes[1]).val());
        if (isNaN(supplied_qty) || isNaN(price_per_unit)) {
            tax_amount = 0.0;
            amount = 0.0
        } else {
            if (isNaN(tax_percentage)) {
                tax_percentage = 0.0;
            } else {
                tax_percentage = tax_percentage / 100;
                tax_amount = (price_per_unit * supplied_qty) * tax_percentage;
                amount = price_per_unit * supplied_qty;
            }
        }
        item_total_amount = amount + tax_amount;
        $(row_elements[7].childNodes[1]).val(parseFloat(tax_amount).toFixed(2));
        $(row_elements[5].childNodes[1]).val(parseFloat(amount).toFixed(2));
        $(row_elements[8].childNodes[1]).val(parseFloat(item_total_amount).toFixed(2));
        total_amount_input = $('.item_total_amount');
        total_amount = 0.0
        for (var amount_input = 0; amount_input < total_amount_input.length; amount_input++) {
            total_amount = parseFloat(total_amount) + parseFloat(total_amount_input[amount_input].value);
        }
        final_total = parseFloat(total_amount);
        $(tfoot_row_elements[1].childNodes[8].childNodes[0]).val(parseFloat(final_total).toFixed(2));
    });

    $(row_elements[6].childNodes[1]).keyup(function () {
        let supplied_qty = parseFloat($(row_elements[3].childNodes[1]).val());
        let price_per_unit = parseFloat($(row_elements[4].childNodes[1]).val());
        let tax_percentage = parseFloat($(row_elements[6].childNodes[1]).val());
        if (isNaN(supplied_qty) || isNaN(price_per_unit)) {
            tax_amount = 0.0;
            amount = 0.0
        } else {
            if (isNaN(tax_percentage)) {
                tax_percentage = 0.0;
            } else {
                tax_percentage = tax_percentage / 100;
                tax_amount = (price_per_unit * supplied_qty) * tax_percentage;
                amount = price_per_unit * supplied_qty;
            }
        }
        item_total_amount = amount + tax_amount;
        $(row_elements[7].childNodes[1]).val(parseFloat(tax_amount).toFixed(2));
        $(row_elements[5].childNodes[1]).val(parseFloat(amount).toFixed(2));
        $(row_elements[8].childNodes[1]).val(parseFloat(item_total_amount).toFixed(2));
        total_amount_input = $('.item_total_amount');
        total_amount = 0.0
        for (var amount_input = 0; amount_input < total_amount_input.length; amount_input++) {
            total_amount = parseFloat(total_amount) + parseFloat(total_amount_input[amount_input].value);
        }
        final_total = parseFloat(total_amount);
        $(tfoot_row_elements[1].childNodes[8].childNodes[0]).val(parseFloat(final_total).toFixed(2));
    });
    // $(tfoot_row_elements[1].childNodes[3].childNodes[0]).keyup(function () {

    //     let supplied_qty = parseFloat($(row_elements[3].childNodes[1]).val());
    //     let price_per_unit = parseFloat($(row_elements[4].childNodes[1]).val());
    //     if (isNaN(supplied_qty) || isNaN(price_per_unit)) {
    //         amount = 0.0;
    //     } else {
    //         amount = price_per_unit * supplied_qty;
    //     }
    //     let tax_amount = $(tfoot_row_elements[1].childNodes[3].childNodes[0]).val();
    //     $(row_elements[5].childNodes[1]).val(parseFloat(amount).toFixed(2));
    //     total_amount_input = $('.item_amount');
    //     total_amount = 0.0
    //     for (var amount_input = 0; amount_input < total_amount_input.length; amount_input++) {
    //         total_amount = parseFloat(total_amount) + parseFloat(total_amount_input[amount_input].value);
    //     }
    //     final_total = parseFloat(total_amount) + parseFloat(tax_amount);
    //     $(tfoot_row_elements[1].childNodes[8].childNodes[0]).val(parseFloat(final_total).toFixed(2));
    // });


    $('.selectpicker.particular_type').selectpicker('refresh');
    $('.selectpicker.unit').selectpicker('refresh');

    $(row_elements[9].childNodes[1].childNodes[0]).click(function () {
        $('.no-borders').remove();
        addRow(in_tbl_name, JSON.stringify(particular_choices), JSON.stringify(unit_choices));
    });
}

//Method to delete dynamic row for invoices
function delRow() {
    var current = window.event.srcElement;
    //here we will delete the line
    while ((current = current.parentElement) && current.tagName != "TR");
    current.parentElement.removeChild(current);
    invoice_count = parseInt(invoice_count) - 1;
    if (invoice_count <= 1) {
        $('.no-borders').remove();
        $('.thead-invoice').remove();
        invoice_table_head = 1
    }
}

// Function for Ordinal Prefix Values
function ordinal_suffix_of(i) {
    var j = i % 10,
        k = i % 100;
    if (j == 1 && k != 11) {
        return i + "st";
    }
    if (j == 2 && k != 12) {
        return i + "nd";
    }
    if (j == 3 && k != 13) {
        return i + "rd";
    }
    return i + "th";
}

// Method to generate the table for member payments
var payment_count = 1;

function memberPaymentContent(table_id, bank_choices, fees_particulars_choices) {
    bank_choices = parse_template_to_json(bank_choices);
    fees_particulars_choices = parse_template_to_json(fees_particulars_choices);
    selected_department = document.getElementsByClassName('department');
    $('.no-borders').remove();
    var tbody = document.getElementById(table_id).getElementsByTagName("tbody")[0];
    var thead = document.getElementById(table_id).getElementsByTagName("thead")[0];
    var tfoot = document.getElementById(table_id).getElementsByTagName("tfoot")[0];
    var tbody_row = document.createElement("tr");
    var thead_row = document.createElement("tr");
    var tfoot_row = document.createElement("tr");
    // create table cell for count of particulars
    var si_header = document.createElement("th");
    si_header.setAttribute('align', 'center');
    si_header.append('SI No');
    var account_header = document.createElement("th");
    account_header.setAttribute('align', 'center');
    account_header.append('Account');
    var particulars_header = document.createElement("th");
    particulars_header.setAttribute('align', 'center');
    particulars_header.append('Particulars')
    var amount_header = document.createElement("th");
    amount_header.setAttribute('align', 'center');
    amount_header.append('Amount')
    var actions_header = document.createElement("th");
    actions_header.setAttribute('align', 'center');
    actions_header.append('Actions')
    var si_number = document.createElement("th");
    si_number.setAttribute('align', 'center');
    si_number.setAttribute('scope', 'row');
    si_number.setAttribute('width', '8%');
    // create table cell for account selection
    var account_info = document.createElement("td");
    account_info.setAttribute('width', '25%');
    var account_HTML = '<' +
        'select class="selectpicker bank_account" ' +
        ' name="bank_account" id="bank_account" ' +
        'data-live-search= "true"></select>';
    account_info.innerHTML = account_HTML.replace(/!payment_count!/g, payment_count);
    var particulars = document.createElement("td");
    particulars.setAttribute('width', '25%');
    var particulars_HTML = ' <' +
        'select class="selectpicker particulars" ' +
        ' name="particulars" id="particulars" ' +
        'data-live-search= "true"></select>';
    particulars.innerHTML = particulars_HTML.replace(/!payment_count!/g, payment_count);
    // create table cell for amount
    var amount = document.createElement("td");
    var amount_HTML = '<input type="number" name="amount" id="amount" class="form-control validate" required>';
    amount.innerHTML = amount_HTML.replace(/!payment_count!/g, payment_count);

    // create table cell for actions
    var actions = document.createElement("td")
    actions.setAttribute('align', 'center');
    var actions_HTML =
        ' <span class="add-remove-invoice-record"><button type="button" class="btn btn-primary btn-sm"><i class="fas fa-plus fa-2x aria-hidden="true"> </i></button>' +
        ' <button class="btn btn-danger btn-sm" onclick=delPaymentRow()><i class="fas fa-trash-alt fa-2x aria-hidden="true"> </i></button> </span>';
    actions.innerHTML = actions_HTML.replace(/!payment_count!/g, payment_count);
    if (thead.childElementCount == 0) {
        thead_row.appendChild(si_header);
        thead_row.appendChild(account_header);
        thead_row.appendChild(particulars_header);
        thead_row.appendChild(amount_header);
        thead_row.appendChild(actions_header);
        thead.appendChild(thead_row);
    }
    if (tfoot.childElementCount == 0) {
        var tfoot_row = document.createElement("tr");
        var empty_col_1 = document.createElement("td");
        var empty_col_2 = document.createElement("td");
        var empty_col_3 = document.createElement("td");
        var empty_col_4 = document.createElement("td");
        var submit = document.createElement("button");
        submit.setAttribute('type', 'submit');
        submit.setAttribute('class', 'btn btn-primary');
        submit.innerHTML = 'Submit';
        tfoot_row.appendChild(empty_col_1);
        tfoot_row.appendChild(empty_col_2);
        tfoot_row.appendChild(empty_col_3);
        tfoot_row.appendChild(empty_col_4);
        tfoot_row.appendChild(submit);
        tfoot.appendChild(tfoot_row);
    }

    tbody_row.appendChild(si_number);
    tbody_row.appendChild(account_info);
    tbody_row.appendChild(particulars);
    tbody_row.appendChild(amount);
    tbody_row.appendChild(actions);
    tbody.appendChild(tbody_row);
    payment_count = payment_count + 1;
    row_elements = tbody_row.childNodes;
    for (var bank_element = 0; bank_element < bank_choices.length; bank_element++) {
        if (bank_choices[bank_element]['department_id'] == selected_department[1].value) {
            option_content = '<option value=' + bank_choices[bank_element]['id'] +
                ' data-tokens="' + bank_choices[bank_element]['account_number'] + '"' +
                ' data-subtext="' + bank_choices[bank_element]['bank_name'] +
                '">' + bank_choices[bank_element]['account_number'] +
                '</option>';
            $(row_elements[1].childNodes[0]).append(option_content);
        }

    }
    for (var particulars_element = 0; particulars_element < fees_particulars_choices.length; particulars_element++) {
        if (fees_particulars_choices[particulars_element]['department_id'] == selected_department[1].value) {
            option_content = '<option value=' + fees_particulars_choices[particulars_element]['id'] +
                ' data-tokens="' + fees_particulars_choices[particulars_element]['particulars'] +
                '">' + fees_particulars_choices[particulars_element]['particulars'] +
                '</option>';
            $(row_elements[2].childNodes[1]).append(option_content);
        }

    }
    $('.selectpicker.bank_account').selectpicker('refresh');
    $('.selectpicker.particulars').selectpicker('refresh');
    for (var particulars_element = 0; particulars_element < fees_particulars_choices.length; particulars_element++) {
        if (fees_particulars_choices[particulars_element]['id'] == $(row_elements[2].childNodes[1].childNodes[2])[0].value) {
            $(row_elements[3].childNodes[0]).val(fees_particulars_choices[particulars_element]['amount']);
        }

    }
    $(row_elements[2].childNodes[1]).on('click', function () {
        for (var particulars_element = 0; particulars_element < fees_particulars_choices.length; particulars_element++) {
            if (fees_particulars_choices[particulars_element]['id'] == $(row_elements[2].childNodes[1].childNodes[2])[0].value) {
                $(row_elements[3].childNodes[0]).val(fees_particulars_choices[particulars_element]['amount']);
            }

        }
    });
    $(row_elements[4].childNodes[1].childNodes[0]).click(function () {
        $('.no-borders').remove();
        addPaymentRow(table_id, JSON.stringify(bank_choices), JSON.stringify(fees_particulars_choices));
    });
}
// Method to add the row to accept payments
function addPaymentRow(table_id, bank_choices, fees_particulars_choices) {
    memberPaymentContent(table_id, bank_choices, fees_particulars_choices)
}
//Method to delete dynamic row for payment
function delPaymentRow() {
    var current = window.event.srcElement;
    //here we will delete the line
    while ((current = current.parentElement) && current.tagName != "TR");
    current.parentElement.removeChild(current);
    payment_count = parseInt(payment_count) - 1;
    if (payment_count <= 1) {
        $('.no-borders').remove();
        $('.thead-payment').empty();
        $('.tfoot-payment').empty();
        $('.tbody-payment').empty();
    }
}


// Method to generate the table for requisition
var requisition_count = 1;

function addRequisitionContent(table_id, particulars_choices) {
    particulars_choices = parse_template_to_json(particulars_choices);
    selected_department = document.getElementsByClassName('department');
    $('.no-borders').remove();
    var tbody = document.getElementById(table_id).getElementsByTagName("tbody")[0];
    var thead = document.getElementById(table_id).getElementsByTagName("thead")[0];
    var tfoot = document.getElementById(table_id).getElementsByTagName("tfoot")[0];
    var tbody_row = document.createElement("tr");
    var thead_row = document.createElement("tr");
    var tfoot_row = document.createElement("tr");
    // create table cell for count of particulars
    var si_header = document.createElement("th");
    si_header.setAttribute('align', 'center');
    si_header.append('SI No');
    var particulars_header = document.createElement("th");
    particulars_header.setAttribute('align', 'center');
    particulars_header.append('Particulars');
    var quantity_header = document.createElement("th");
    quantity_header.setAttribute('align', 'center');
    quantity_header.append('Quantity')
    var actions_header = document.createElement("th");
    actions_header.setAttribute('align', 'center');
    actions_header.append('Actions')
    var si_number = document.createElement("th");
    si_number.setAttribute('align', 'center');
    si_number.setAttribute('scope', 'row');
    si_number.setAttribute('width', '10%');
    // create table cell for particular selection
    var particulars = document.createElement("td");
    particulars.setAttribute('width', '50%');
    var particulars_HTML = ' <' +
        'select class="selectpicker particulars" ' +
        ' name="particulars" id="particulars" ' +
        'data-live-search= "true"></select>';
    particulars.innerHTML = particulars_HTML.replace(/!requisition_count!/g, requisition_count);
    // create table cell for quantity
    var quantity_requested = document.createElement("td");
    var quantity_requested_HTML = '<input type="number" name="quantity_requested" id="quantity_requested" class="form-control validate" required>';
    quantity_requested.innerHTML = quantity_requested_HTML.replace(/!requisition_count!/g, requisition_count);

    // create table cell for actions
    var actions = document.createElement("td")
    actions.setAttribute('align', 'center');
    var actions_HTML =
        ' <span class="add-remove-invoice-record"><button type="button" class="btn btn-primary btn-sm"><i class="fas fa-plus fa-2x aria-hidden="true"> </i></button>' +
        ' <button class="btn btn-danger btn-sm" onclick=delRequisitionRow()><i class="fas fa-trash-alt fa-2x aria-hidden="true"> </i></button> </span>';
    actions.innerHTML = actions_HTML.replace(/!requisition_count!/g, requisition_count);
    if (thead.childElementCount == 0) {
        thead_row.appendChild(si_header);
        thead_row.appendChild(particulars_header);
        thead_row.appendChild(quantity_header);
        thead_row.appendChild(actions_header);
        thead.appendChild(thead_row);
    }
    if (tfoot.childElementCount == 0) {
        var tfoot_row = document.createElement("tr");
        var empty_col_1 = document.createElement("td");
        var empty_col_2 = document.createElement("td");
        var empty_col_3 = document.createElement("td");
        var submit = document.createElement("button");
        submit.setAttribute('type', 'submit');
        submit.setAttribute('class', 'btn btn-primary');
        submit.innerHTML = 'Submit';
        tfoot_row.appendChild(empty_col_1);
        tfoot_row.appendChild(empty_col_2);
        tfoot_row.appendChild(empty_col_3);
        tfoot_row.appendChild(submit);
        tfoot.appendChild(tfoot_row);
    }

    tbody_row.appendChild(si_number);
    tbody_row.appendChild(particulars);
    tbody_row.appendChild(quantity_requested);
    tbody_row.appendChild(actions);
    tbody.appendChild(tbody_row);
    requisition_count = requisition_count + 1;
    row_elements = tbody_row.childNodes;

    for (var particulars_element = 0; particulars_element < particulars_choices.length; particulars_element++) {

        option_content = '<option value=' + particulars_choices[particulars_element]['id'] +
            ' data-tokens="' + particulars_choices[particulars_element]['name'] + '"' +
            ' data-subtext="' + particulars_choices[particulars_element]['unit'] +
            '">' + particulars_choices[particulars_element]['name'] +
            '</option>';
        $(row_elements[1].childNodes[1]).append(option_content);
    }
    $('.selectpicker.particulars').selectpicker('refresh');
    $(submit).click(function () {
        let particulars_list = $('select#particulars');
        let particulars_list_value = []
        for (var particulars_element = 0; particulars_element < particulars_list.length; particulars_element++) {
            particulars_list_value[particulars_element] = $('select#particulars')[particulars_element].value;
        }
        var duplicates = particulars_list_value.reduce(function (acc, el, i, arr) {
            if (arr.indexOf(el) !== i && acc.indexOf(el) < 0) acc.push(el);
            return acc;
        }, []);
        if (duplicates.length > 0) {
            swal(
                'Status Update',
                'Duplicate Particulars Exists',
                'error',
                'timer: 1000')
            return false;
        }

    });
    $(row_elements[3].childNodes[1].childNodes[0]).click(function () {
        $('.no-borders').remove();
        addRequisitionRow(table_id, JSON.stringify(particulars_choices));
    });
}
// Method to add the row to accept payments
function addRequisitionRow(table_id, particulars_choices) {
    addRequisitionContent(table_id, particulars_choices)
}
//Method to delete dynamic row for payment
function delRequisitionRow() {
    var current = window.event.srcElement;
    //here we will delete the line
    while ((current = current.parentElement) && current.tagName != "TR");
    current.parentElement.removeChild(current);
    requisition_count = parseInt(requisition_count) - 1;
    if (requisition_count <= 1) {
        $('.no-borders').remove();
        $('.thead-requisition').empty();
        $('.tfoot-requisition').empty();
    }
}

// Generate the dynamic table for requisition details
function get_requisition_details(table_id, requisition_id, requisition_details) {
    var table_id = document.getElementById(table_id);
    var table = $(table_id).DataTable();
    var tr = $(requisition_id).closest('tr');
    var row = table.row(tr);
    requisition_details = parse_template_to_json(requisition_details);
    $('.requisition-details').removeClass('shown');
    $('.requisition-details-header').remove();
    $('.requisition-details-content').remove();
    var thead_row = document.createElement('tr')
    thead_row.setAttribute('class', 'requisition-details-header');
    thead_row.setAttribute('align', 'center');
    thead_row.style.background = "#FFDEAD";
    var req_si = document.createElement('th');
    req_si.innerHTML = 'SI No';
    var req_particulars = document.createElement('th');
    req_particulars.innerHTML = 'Particulars';
    var req_requested_quantity = document.createElement('th');
    req_requested_quantity.innerHTML = 'Quantity Requested';
    var req_supplied_quantity = document.createElement('th');
    req_supplied_quantity.innerHTML = 'Quantity Supplied';
    thead_row.appendChild(req_si);
    thead_row.appendChild(req_particulars);
    thead_row.appendChild(req_requested_quantity);
    thead_row.appendChild(req_supplied_quantity);
    row.child(thead_row).show();

    for (var requisition_element = 0; requisition_element < requisition_details.length; requisition_element++) {
        if (requisition_details[requisition_element]['id'] == requisition_id.childNodes[3].textContent) {
            current_element_length = requisition_details[requisition_element]['requisition_details'].length;
            var counter = 1;
            for (var req_details_element = current_element_length - 1; req_details_element >= 0; req_details_element--) {
                particulars = requisition_details[requisition_element]['requisition_details'][req_details_element]['particulars'];
                quantity_requested = requisition_details[requisition_element]['requisition_details'][req_details_element]['quantity_requested'];
                quantity_supplied = requisition_details[requisition_element]['requisition_details'][req_details_element]['quantity_supplied'];
                unit = requisition_details[requisition_element]['requisition_details'][req_details_element]['unit'];
                var req_details_row = document.createElement('tr');
                req_details_row.setAttribute('class', 'requisition-details-content')
                var req_details_si = document.createElement('td');
                req_details_si.setAttribute('align', 'center');
                req_details_si.innerHTML = req_details_element + 1;
                var req_details_particulars = document.createElement('td');
                req_details_particulars.innerHTML = particulars;
                var req_details_qty_requested = document.createElement('td');
                req_details_qty_requested.innerHTML = quantity_requested + ' - ' + unit;
                var req_details_qty_supplied = document.createElement('td');
                req_details_qty_supplied.innerHTML = quantity_supplied + ' - ' + unit;;
                req_details_row.appendChild(req_details_si);
                req_details_row.appendChild(req_details_particulars);
                req_details_row.appendChild(req_details_qty_requested);
                req_details_row.appendChild(req_details_qty_supplied);
                $(req_details_row).insertAfter($(thead_row));
                counter = counter + 1;
            }
        }
    }

    tr.addClass('shown');

}

function verify_requisition_details(table_id, requisition_id, requisition_details) {
    var table_id = document.getElementById(table_id);
    var table = $(table_id).DataTable();
    var tr = $(requisition_id).closest('tr');
    var row = table.row(tr);
    requisition_details = parse_template_to_json(requisition_details);
    $('.requisition-details').removeClass('shown');
    $('.requisition-details-header').remove();
    $('.requisition-details-footer').remove();
    $('.requisition-details-content').remove();
    var thead_row = document.createElement('tr')
    thead_row.setAttribute('class', 'requisition-details-header');
    thead_row.setAttribute('align', 'center');
    thead_row.style.background = "#FFDEAD";
    var req_si = document.createElement('th');
    req_si.innerHTML = 'SI No';
    var req_particulars = document.createElement('th');
    req_particulars.innerHTML = 'Particulars';
    var req_requested_quantity = document.createElement('th');
    req_requested_quantity.innerHTML = 'Quantity Requested';
    var req_supplied_quantity = document.createElement('th');
    req_supplied_quantity.innerHTML = 'Quantity Supplied';
    thead_row.appendChild(req_si);
    thead_row.appendChild(req_particulars);
    thead_row.appendChild(req_requested_quantity);
    thead_row.appendChild(req_supplied_quantity);
    row.child(thead_row).show();
    var tfoot_row = document.createElement("tr");
    tfoot_row.setAttribute('class', 'requisition-details-footer')
    var empty_col_1 = document.createElement("td");
    var empty_col_2 = document.createElement("td");
    var empty_col_3 = document.createElement("td");
    var empty_col_4 = document.createElement("td");
    empty_col_4.setAttribute('align', 'right');

    var submit = document.createElement("button");
    submit.setAttribute('type', 'button');
    submit.setAttribute('data-toggle', 'modal');
    submit.setAttribute('class', 'button-royalblue approve-requisition');

    submit.innerHTML = 'Approve';
    tfoot_row.appendChild(empty_col_1);
    tfoot_row.appendChild(empty_col_2);
    tfoot_row.appendChild(empty_col_3);
    empty_col_4.appendChild(submit);
    tfoot_row.appendChild(empty_col_4);
    $(tfoot_row).insertAfter($(thead_row));

    for (var requisition_element = 0; requisition_element < requisition_details.length; requisition_element++) {
        if (requisition_details[requisition_element]['id'] == requisition_id.childNodes[3].textContent) {
            current_element_length = requisition_details[requisition_element]['requisition_details'].length;
            var counter = 1;
            for (var req_details_element = current_element_length - 1; req_details_element >= 0; req_details_element--) {
                particulars = requisition_details[requisition_element]['requisition_details'][req_details_element]['particulars'];
                quantity_requested = requisition_details[requisition_element]['requisition_details'][req_details_element]['quantity_requested'];
                quantity_supplied = requisition_details[requisition_element]['requisition_details'][req_details_element]['quantity_supplied'];
                unit = requisition_details[requisition_element]['requisition_details'][req_details_element]['unit'];
                var req_details_row = document.createElement('tr');
                req_details_row.setAttribute('class', 'requisition-details-content')
                var req_details_si = document.createElement('td');
                req_details_si.setAttribute('align', 'center');
                req_details_si.innerHTML = req_details_element + 1;
                var req_details_particulars = document.createElement('td');
                req_details_particulars.innerHTML = particulars;
                var req_details_qty_requested = document.createElement('td');
                req_details_qty_requested.innerHTML = quantity_requested + ' - ' + unit;
                var req_details_qty_supplied = document.createElement('td');
                req_details_qty_supplied.innerHTML = quantity_supplied + ' - ' + unit;;
                req_details_row.appendChild(req_details_si);
                req_details_row.appendChild(req_details_particulars);
                req_details_row.appendChild(req_details_qty_requested);
                req_details_row.appendChild(req_details_qty_supplied);
                $(req_details_row).insertAfter($(thead_row));
                counter = counter + 1;
            }

        }
    }

    tr.addClass('shown');
    $(submit).click(function () {
        $('#approveRequisitionModel').modal({
            show: true
        });
        $('#requisition_id').text('#' + requisition_id.childNodes[3].textContent);
        var tbody_class = 'approve-requisition-body';
        var tbody = document.getElementsByClassName(tbody_class)[0];
        $('.' + tbody_class + ' tr ').remove();
        for (var requisition_element = 0; requisition_element < requisition_details.length; requisition_element++) {
            if (requisition_details[requisition_element]['id'] == requisition_id.childNodes[3].textContent) {
                current_element_length = requisition_details[requisition_element]['requisition_details'].length;
                $('#edit_requisition_id').val(requisition_id.childNodes[3].textContent);
                for (var req_details_element = 0; req_details_element < current_element_length; req_details_element++) {
                    requisition_id = requisition_details[requisition_element]['requisition_details'][req_details_element]['id'];
                    particulars_content = requisition_details[requisition_element]['requisition_details'][req_details_element]['particulars'];
                    unit_content = requisition_details[requisition_element]['requisition_details'][req_details_element]['unit'];
                    total_quantity = requisition_details[requisition_element]['requisition_details'][req_details_element]['inventory'];
                    quantity_requested = requisition_details[requisition_element]['requisition_details'][req_details_element]['quantity_requested'];
                    var table_row = document.createElement('tr');
                    var si_number = document.createElement('th');
                    var particulars = document.createElement('td');
                    var total_qty = document.createElement('td');
                    var requested_qty = document.createElement('td');
                    var supplied_qty = document.createElement('td');
                    si_number.innerHTML = req_details_element + 1;
                    particulars.innerHTML = '<input type="text" name="particulars" id="particulars" class="form-control validate" required readonly value="' + particulars_content + ' - ' + unit_content + '"> <input type="hidden" name="requisition_details_id" id="requisition_details_id" value="' + requisition_id + '">';
                    total_qty.innerHTML = '<input type="number" name="inventory" id="inventory" class="form-control validate" required readonly step="0.01" value="' + total_quantity + '">';
                    requested_qty.innerHTML = '<input type="number" name="quantity_requested" id="quantity_requested" class="form-control validate" step="0.01" readonly required value="' + quantity_requested + '"> <input type="hidden" name="quantity_total" id="quantity_total" step="0.01" value="' + total_quantity + '">';
                    if (total_quantity == 0) {
                        supplied_qty.innerHTML = '<input type="number" name="quantity_supplied" id="quantity_supplied" class="form-control validate" step="0.01" readonly step="0.01" value="' + total_quantity + '">';
                    } else if (total_quantity <= quantity_requested) {
                        supplied_qty.innerHTML = '<input type="number" name="quantity_supplied" id="quantity_supplied" class="form-control validate" step="0.01" step="0.01" max="' + total_quantity + '" value="' + total_quantity + '">';
                    } else if (quantity_requested <= total_quantity) {
                        supplied_qty.innerHTML = '<input type="number" name="quantity_supplied" id="quantity_supplied" class="form-control validate" step="0.01" step="0.01" max="' + total_quantity + '" value="' + quantity_requested + '">';
                    } else {
                        supplied_qty.innerHTML = '<input type="number" name="quantity_supplied" id="quantity_supplied" class="form-control validate" step="0.01" required max="' + quantity_requested + '" > ';
                    }

                    table_row.appendChild(si_number);
                    table_row.appendChild(particulars);
                    table_row.appendChild(total_qty);
                    table_row.appendChild(requested_qty);
                    table_row.appendChild(supplied_qty);
                    tbody.appendChild(table_row);

                }

            }
        }
    });

}

// Method to generate the table for adding the hostel rooms
var room_count = 1;

function hostelRoomContent(table_id) {
    $('.no-borders').remove();
    var tbody = document.getElementById(table_id).getElementsByTagName("tbody")[0];
    var thead = document.getElementById(table_id).getElementsByTagName("thead")[0];
    var tfoot = document.getElementById(table_id).getElementsByTagName("tfoot")[0];
    var tbody_row = document.createElement("tr");
    var thead_row = document.createElement("tr");
    var tfoot_row = document.createElement("tr");
    thead_row.setAttribute('align', 'center');
    // create table cell for count of particulars
    var si_header = document.createElement("th");
    si_header.setAttribute('align', 'center');
    si_header.append('SI No');
    var room_number_header = document.createElement("th");
    room_number_header.setAttribute('align', 'center');
    room_number_header.append('Room Number');
    var room_capacity_header = document.createElement("th");
    room_capacity_header.setAttribute('align', 'center');
    room_capacity_header.append('Capacity')
    var actions_header = document.createElement("th");
    actions_header.setAttribute('align', 'center');
    actions_header.append('Actions')
    var si_number = document.createElement("th");
    si_number.setAttribute('align', 'center');
    si_number.setAttribute('scope', 'row');
    si_number.setAttribute('width', '8%');

    // create table cell for adding the room numbers
    var room_number = document.createElement("td");
    var room_number_HTML = '<input type="text" name="room_number" id="room_number" class="form-control validate room_number text-uppercase" required>';
    room_number.innerHTML = room_number_HTML.replace(/!room_count!/g, room_count);

    // Create the table cell for adding the room capacity
    var capacity = document.createElement("td");
    var capacity_HTML = '<input type="number" name="capacity" id="capacity" class="form-control capacity validate" required>';
    capacity.innerHTML = capacity_HTML.replace(/!room_count!/g, room_count);

    // create table cell for actions
    var actions = document.createElement("td")
    actions.setAttribute('align', 'center');
    var actions_HTML =
        ' <span class="add-remove-invoice-record"><button type="button" class="btn btn-primary btn-sm"><i class="fas fa-plus fa-2x aria-hidden="true"> </i></button>' +
        ' <button class="btn btn-danger btn-sm" onclick=delHostelRoomContent()><i class="fas fa-trash-alt fa-2x aria-hidden="true"> </i></button> </span>';
    actions.innerHTML = actions_HTML.replace(/!room_count!/g, room_count);
    if (thead.childElementCount == 0) {
        thead_row.appendChild(si_header);
        thead_row.appendChild(room_number_header);
        thead_row.appendChild(room_capacity_header);
        thead_row.appendChild(actions_header);
        thead.appendChild(thead_row);
    }
    if (tfoot.childElementCount == 0) {
        var tfoot_row = document.createElement("tr");
        var empty_col_1 = document.createElement("td");
        var empty_col_2 = document.createElement("td");
        var empty_col_3 = document.createElement("td");
        var empty_col_4 = document.createElement("td");
        var submit = document.createElement("button");
        empty_col_4.setAttribute('align', 'right');
        submit.setAttribute('type', 'submit');
        submit.setAttribute('class', 'btn btn-primary');
        submit.innerHTML = 'Submit';
        empty_col_4.appendChild(submit);
        tfoot_row.appendChild(empty_col_1);
        tfoot_row.appendChild(empty_col_2);
        tfoot_row.appendChild(empty_col_3);
        tfoot_row.appendChild(empty_col_4);
        tfoot.appendChild(tfoot_row);
    }

    tbody_row.appendChild(si_number);
    tbody_row.appendChild(room_number);
    tbody_row.appendChild(capacity);
    tbody_row.appendChild(actions);
    tbody.appendChild(tbody_row);
    room_count = room_count + 1;
    row_elements = tbody_row.childNodes;
    $(row_elements[3].childNodes[1].childNodes[0]).click(function () {
        $('.no-borders').remove();
        addHostelRoomRow(table_id);
    });
}
// Method to add the row to accept payments
function addHostelRoomRow(table_id) {
    hostelRoomContent(table_id)
}
//Method to delete dynamic row for payment
function delHostelRoomContent() {
    var current = window.event.srcElement;
    //here we will delete the line
    while ((current = current.parentElement) && current.tagName != "TR");
    current.parentElement.removeChild(current);
    room_count = parseInt(room_count) - 1;
    if (room_count <= 1) {
        $('.no-borders').remove();
        $('.thead-room-records').empty();
        $('.tfoot-room-records').empty();
    }
}

function allocate_hostel_rooms(room_details) {
    room_details = parse_template_to_json(room_details);
    jQuery('#memberHostelRoom').click(function (e) {
        url = '/department/allocate_rooms/';
        $('.modal-container').load(url, function (result) {
            $('#memberHostelRoom').modal({
                show: true
            });
        });
    });
    $('#room_number').text('#' + room_details['room_number']);
    $('#room_number_id').val(room_details['id']);
}